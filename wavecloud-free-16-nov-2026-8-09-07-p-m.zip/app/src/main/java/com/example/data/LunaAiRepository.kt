package com.example.data

import android.graphics.Bitmap
import com.example.model.CharacterConceptDraft
import com.example.model.VideoDirectionDraft
import com.google.firebase.Firebase
import com.google.firebase.ai.GenerativeModel
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.AspectRatio
import com.google.firebase.ai.type.ImageConfig
import com.google.firebase.ai.type.ImagePart
import com.google.firebase.ai.type.ImageSize
import com.google.firebase.ai.type.ResponseModality
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.withTimeout
import org.json.JSONObject
import kotlin.random.Random

class LunaAiRepository {

    private val generalFlashModel: GenerativeModel by lazy {
        Firebase.ai.generativeModel(modelName = "gemini-3.8-flash")
    }

    private val directionJsonModel: GenerativeModel by lazy {
        val schema = Schema.obj(
            properties = mapOf(
                "title" to Schema.string(description = "Título corto y evocador en español para el proyecto"),
                "cameraPrompt" to Schema.string(description = "Prompt detallado de cámara, ángulos, movimientos e iluminación cinematográfica en español"),
                "voiceoverScript" to Schema.string(description = "Guion narrativo poético y claro en español acorde a la duración"),
                "keyframePrompts" to Schema.array(
                    items = Schema.string(),
                    description = "Exactamente 4 prompts visuales descriptivos secuenciales para los fotogramas clave"
                )
            )
        )
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = schema
            }
        )
    }

    private val characterJsonModel: GenerativeModel by lazy {
        val schema = Schema.obj(
            properties = mapOf(
                "codeName" to Schema.string(description = "Nombre o código del personaje estilo Luna-002 o Nova-007"),
                "description" to Schema.string(description = "Descripción visual detallada en español para personaje 100% sintético"),
                "seed" to Schema.integer(description = "Número semilla entero positivo de 6 dígitos")
            )
        )
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = schema
            }
        )
    }

    private fun buildImageModel(
        modelId: String,
        aspectRatio: String,
        resolution: String
    ): GenerativeModel {
        val mappedAspect = when (aspectRatio) {
            "16:9" -> AspectRatio.LANDSCAPE_16x9
            "9:16" -> AspectRatio.PORTRAIT_9x16
            "3:4" -> AspectRatio.PORTRAIT_3x4
            "4:3" -> AspectRatio.LANDSCAPE_4x3
            else -> AspectRatio.SQUARE_1x1
        }
        val mappedSize = when (resolution) {
            "2K" -> ImageSize.SIZE_2K
            else -> ImageSize.SIZE_1K
        }
        val config = generationConfig {
            responseModalities = listOf(ResponseModality.IMAGE)
            imageConfig = ImageConfig.builder()
                .setAspectRatio(mappedAspect)
                .setImageSize(mappedSize)
                .build()
        }
        return Firebase.ai.generativeModel(
            modelName = modelId,
            generationConfig = config
        )
    }

    suspend fun generateInspirationTopic(): String {
        val prompt = """
            Genera una sola idea creativa y cinematográfica en español (máximo 220 caracteres, sin comillas)
            para un video corto de IA con estética futurista, editorial o natural.
            Responde únicamente con el texto de la idea.
        """.trimIndent()
        val response = withTimeout(45_000L) {
            generalFlashModel.generateContent(prompt)
        }
        return response.text?.trim()?.take(280)
            ?: throw IllegalStateException("No se recibió inspiración del modelo en la nube.")
    }

    suspend fun enhanceImagePrompt(rawPrompt: String, styleLook: String): String {
        val prompt = """
            Mejora y enriquece el siguiente prompt visual manteniendo su intención original en español,
            incorporando iluminación profesional, composición, textura y estética "$styleLook" (máximo 450 caracteres).
            Prompt original: "$rawPrompt"
            Responde únicamente con el prompt mejorado.
        """.trimIndent()
        val response = withTimeout(45_000L) {
            generalFlashModel.generateContent(prompt)
        }
        return response.text?.trim()?.take(1200)
            ?: throw IllegalStateException("El modelo devolvió una respuesta vacía.")
    }

    suspend fun assembleVideoDirection(
        topic: String,
        lookStyle: String,
        cameraModel: String,
        lens: String,
        durationSec: Int
    ): VideoDirectionDraft {
        val prompt = """
            Actúa como un director de fotografía y guionista para Luna AI.
            Tema del video: "$topic"
            Estilo/Look: $lookStyle
            Cámara: $cameraModel
            Lente: $lens
            Duración total: $durationSec segundos.
            Genera:
            1) Un título breve en español.
            2) Un prompt de cámara detallado (movimientos, ángulo, iluminación y atmósfera).
            3) Un guion de voz en off natural y atrapante para durar ~$durationSec segundos.
            4) Exactamente 4 prompts visuales secuenciales para los 4 fotogramas clave de la historia.
        """.trimIndent()

        val response = withTimeout(60_000L) {
            directionJsonModel.generateContent(prompt)
        }
        val jsonStr = response.text ?: throw IllegalStateException("Respuesta vacía al armar dirección.")
        val json = JSONObject(jsonStr)
        val keyframesJson = json.optJSONArray("keyframePrompts")
        val keyframes = buildList {
            if (keyframesJson != null) {
                for (i in 0 until keyframesJson.length()) {
                    val item = keyframesJson.optString(i).trim()
                    if (item.isNotBlank()) add(item)
                }
            }
        }.ifEmpty {
            listOf(
                "$topic, toma inicial amplia con estética $lookStyle y lente $lens",
                "$topic, plano medio cinematográfico con iluminación dramática",
                "$topic, primer plano detallado con profundidad de campo suave",
                "$topic, toma final épica con atmósfera envolvente"
            )
        }

        return VideoDirectionDraft(
            title = json.optString("title", "Escena Luna AI").ifBlank { "Escena Luna AI" },
            cameraPrompt = json.optString("cameraPrompt", ""),
            voiceoverScript = json.optString("voiceoverScript", ""),
            keyframePrompts = keyframes.take(4)
        )
    }

    suspend fun generateCharacterConcept(stylePreset: String): CharacterConceptDraft {
        val prompt = """
            Diseña un personaje virtual 100% original e imaginario (no basado en personas reales) para un estudio creativo llamado Luna AI.
            Estilo visual: $stylePreset.
            Devuelve un código de nombre (ej. Nova-004, Astra-009), una descripción visual rica de rostro, vestuario e iluminación en español, y un seed numérico de 6 dígitos.
        """.trimIndent()
        val response = withTimeout(45_000L) {
            characterJsonModel.generateContent(prompt)
        }
        val jsonStr = response.text ?: throw IllegalStateException("No se pudo generar el concepto del personaje.")
        val json = JSONObject(jsonStr)
        return CharacterConceptDraft(
            codeName = json.optString("codeName", "Nova-${Random.nextInt(100, 999)}"),
            description = json.optString("description", "Personaje sintético estilo $stylePreset con iluminación cinematográfica."),
            seed = json.optLong("seed", Random.nextLong(100_000L, 999_999L)).coerceAtLeast(1000L)
        )
    }

    suspend fun generateImage(
        prompt: String,
        modelId: String = "gemini-nano-banana-2.1",
        aspectRatio: String = "1:1",
        resolution: String = "1K",
        styleLook: String = "Profesional",
        referenceBitmap: Bitmap? = null
    ): Bitmap {
        val model = buildImageModel(modelId, aspectRatio, resolution)
        val fullPrompt = "Estética: $styleLook. Alta calidad cinematográfica, sin texto ni marcas de agua. $prompt"
        val response = withTimeout(60_000L) {
            if (referenceBitmap != null) {
                model.generateContent(
                    content {
                        image(referenceBitmap)
                        text("Usa esta imagen como referencia visual y transfórmala siguiendo la instrucción: $fullPrompt")
                    }
                )
            } else {
                model.generateContent(fullPrompt)
            }
        }
        val imagePart = response.candidates.firstOrNull()
            ?.content?.parts?.filterIsInstance<ImagePart>()
            ?.firstOrNull()
        return imagePart?.image
            ?: throw IllegalStateException("El modelo no devolvió ninguna imagen. Ajusta el prompt e intenta nuevamente.")
    }

    suspend fun generateCharacterVariation(
        baseDescription: String,
        expressionInstruction: String,
        stylePreset: String,
        referenceBitmap: Bitmap? = null
    ): Bitmap {
        val model = buildImageModel(
            modelId = "gemini-nano-banana-2.1",
            aspectRatio = "3:4",
            resolution = "1K"
        )
        val prompt = """
            Retrato de estudio editorial de personaje 100% sintético e imaginario (no persona real).
            Estética: $stylePreset. Fondo oscuro profundo #0B0F19. Sin texto.
            Personaje: $baseDescription.
            Variación facial / ángulo: $expressionInstruction.
        """.trimIndent()
        val response = withTimeout(60_000L) {
            if (referenceBitmap != null) {
                model.generateContent(
                    content {
                        image(referenceBitmap)
                        text("Mantén exactamente la identidad facial del personaje de referencia pero cambia la expresión y ángulo: $expressionInstruction. $prompt")
                    }
                )
            } else {
                model.generateContent(prompt)
            }
        }
        val imagePart = response.candidates.firstOrNull()
            ?.content?.parts?.filterIsInstance<ImagePart>()
            ?.firstOrNull()
        return imagePart?.image
            ?: throw IllegalStateException("No se pudo generar la variación facial.")
    }
}

package com.example.data

import android.content.Context
import com.example.R
import com.example.core.OperationType
import com.example.core.handleFirestoreError
import com.example.model.GeneratedMedia
import com.example.model.LunaCharacter
import com.example.model.VideoProject
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.UUID
import kotlin.coroutines.cancellation.CancellationException

class LunaFirestoreRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUid(expectedUserId: String): String {
        val uid = auth.currentUser?.uid
            ?: throw IllegalStateException("Debes iniciar sesión con Google para sincronizar con la nube.")
        check(uid == expectedUserId) { "La sesión activa cambió; operación cancelada." }
        return uid
    }

    fun observeCharacters(userId: String): Flow<List<LunaCharacter>> {
        val path = "users/$userId/characters"
        return db.collection("users").document(userId).collection("characters")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    LunaCharacter::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ).sortedByDescending { it.updatedAt ?: it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val exceptionToLog = firestoreError ?: (error as? Exception)
                if (exceptionToLog != null && auth.currentUser?.uid == userId) {
                    handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                }
                throw error
            }
    }

    fun observeProjects(userId: String): Flow<List<VideoProject>> {
        val path = "users/$userId/projects"
        return db.collection("users").document(userId).collection("projects")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    VideoProject::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ).sortedByDescending { it.updatedAt ?: it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val exceptionToLog = firestoreError ?: (error as? Exception)
                if (exceptionToLog != null && auth.currentUser?.uid == userId) {
                    handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                }
                throw error
            }
    }

    fun observeGenerations(userId: String): Flow<List<GeneratedMedia>> {
        val path = "users/$userId/generations"
        return db.collection("users").document(userId).collection("generations")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    GeneratedMedia::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ).sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val exceptionToLog = firestoreError ?: (error as? Exception)
                if (exceptionToLog != null && auth.currentUser?.uid == userId) {
                    handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                }
                throw error
            }
    }

    suspend fun saveCharacter(userId: String, character: LunaCharacter): Result<String> {
        val docId = character.id.takeIf { it.matches(Regex("^[a-zA-Z0-9_\\-]+$")) }
            ?: "char_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val path = "users/$userId/characters/$docId"
        return try {
            val uid = requireUid(userId)
            val docRef = db.collection("users").document(uid).collection("characters").document(docId)
            val existing = docRef.get().await()
            if (existing.exists()) {
                docRef.update(character.toUpdateMap()).await()
            } else {
                docRef.set(character.toCreateMap(uid)).await()
            }
            Result.success(docId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun saveVideoProject(userId: String, project: VideoProject): Result<String> {
        val docId = project.id.takeIf { it.matches(Regex("^[a-zA-Z0-9_\\-]+$")) }
            ?: "proj_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val path = "users/$userId/projects/$docId"
        return try {
            val uid = requireUid(userId)
            val docRef = db.collection("users").document(uid).collection("projects").document(docId)
            val existing = docRef.get().await()
            if (existing.exists() && existing.getString("status") != "archived") {
                val updateMap = mapOf(
                    "title" to project.title.trim().ifBlank { "Proyecto Luna" }.take(120),
                    "topic" to project.topic.take(300),
                    "cameraPrompt" to project.cameraPrompt.take(1500),
                    "voiceoverScript" to project.voiceoverScript.take(1500),
                    "durationSec" to project.durationSec.coerceIn(5L, 30L),
                    "lookStyle" to project.lookStyle.take(40).ifBlank { "Profesional" },
                    "cameraModel" to project.cameraModel.take(60).ifBlank { "ARRI Alexa 35" },
                    "lens" to project.lens.take(40).ifBlank { "50 mm" },
                    "warmLightPct" to project.warmLightPct.coerceIn(0L, 100L),
                    "grainPct" to project.grainPct.coerceIn(0L, 100L),
                    "voiceName" to project.voiceName.take(40).ifBlank { "Luna Clara" },
                    "voicePace" to project.voicePace.take(40).ifBlank { "Natural" },
                    "status" to if (project.status in listOf("draft", "generating", "ready", "archived")) project.status else "ready",
                    "keyframePaths" to project.keyframePaths.take(8).map { it.take(300) },
                    "referenceImagePath" to project.referenceImagePath.take(300),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.update(updateMap).await()
            } else {
                docRef.set(project.toCreateMap(uid)).await()
            }
            Result.success(docId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun saveGeneratedMedia(userId: String, media: GeneratedMedia): Result<String> {
        val docId = media.id.takeIf { it.matches(Regex("^[a-zA-Z0-9_\\-]+$")) }
            ?: "gen_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val path = "users/$userId/generations/$docId"
        return try {
            val uid = requireUid(userId)
            val docRef = db.collection("users").document(uid).collection("generations").document(docId)
            docRef.set(media.toCreateMap(uid)).await()
            Result.success(docId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun toggleFavorite(userId: String, generationId: String, favorite: Boolean): Result<Unit> {
        val path = "users/$userId/generations/$generationId"
        return try {
            val uid = requireUid(userId)
            require(generationId.isNotBlank()) { "ID inválido." }
            db.collection("users").document(uid).collection("generations").document(generationId)
                .update(
                    mapOf(
                        "favorite" to favorite,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteGeneration(userId: String, generationId: String): Result<Unit> {
        val path = "users/$userId/generations/$generationId"
        return try {
            val uid = requireUid(userId)
            require(generationId.isNotBlank()) { "ID inválido." }
            db.collection("users").document(uid).collection("generations").document(generationId)
                .delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    suspend fun seedDefaultCharacterIfEmpty(userId: String, defaultLocalPath: String): Result<Unit> {
        val path = "users/$userId/characters"
        return try {
            val uid = requireUid(userId)
            val col = db.collection("users").document(uid).collection("characters")
            val snap = col.limit(1).get().await()
            if (snap.isEmpty) {
                val starter = LunaCharacter(
                    id = "luna_001",
                    userId = uid,
                    codeName = "Luna-001",
                    seed = 849201L,
                    description = "Personaje IA original con estilo editorial futurista, cabello plateado-violeta luminiscente, iluminación neón cian y lente 50 mm.",
                    stylePreset = "Profesional",
                    selectedVariation = 0L,
                    activeStatus = true,
                    localImagePath = defaultLocalPath,
                    variationPaths = listOf(defaultLocalPath)
                )
                col.document("luna_001").set(starter.toCreateMap(uid)).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }
}

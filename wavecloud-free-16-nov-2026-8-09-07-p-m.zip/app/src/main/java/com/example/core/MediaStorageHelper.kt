package com.example.core

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.annotation.DrawableRes
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import kotlin.math.max
import kotlin.math.min

object MediaStorageHelper {

    private fun mediaDir(context: Context): File {
        val dir = File(context.filesDir, "luna_media")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    suspend fun saveBitmapToInternal(
        context: Context,
        bitmap: Bitmap,
        fileNamePrefix: String
    ): String = withContext(Dispatchers.IO) {
        val file = File(mediaDir(context), "${fileNamePrefix}_${System.currentTimeMillis()}.jpg")
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)
        }
        file.absolutePath
    }

    suspend fun ensureDrawableCached(
        context: Context,
        @DrawableRes resId: Int,
        fileName: String
    ): String = withContext(Dispatchers.IO) {
        val file = File(mediaDir(context), fileName)
        if (!file.exists()) {
            val bitmap = BitmapFactory.decodeResource(context.resources, resId)
            if (bitmap != null) {
                FileOutputStream(file).use { out ->
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)
                }
            }
        }
        file.absolutePath
    }

    suspend fun copyPickedUriToInternal(
        context: Context,
        uri: Uri,
        fileNamePrefix: String = "ref"
    ): Pair<String, Bitmap?> = withContext(Dispatchers.IO) {
        val decoded = context.contentResolver.openInputStream(uri)?.use { stream ->
            BitmapFactory.decodeStream(stream)
        } ?: return@withContext "" to null

        val scaled = scaleBitmapMaxEdge(decoded, 1024)
        val path = saveBitmapToInternal(context, scaled, fileNamePrefix)
        path to scaled
    }

    fun loadBitmapFromPath(path: String): Bitmap? {
        if (path.isBlank()) return null
        val file = File(path)
        if (!file.exists()) return null
        return BitmapFactory.decodeFile(file.absolutePath)
    }

    private fun scaleBitmapMaxEdge(bitmap: Bitmap, maxEdge: Int): Bitmap {
        val w = bitmap.width
        val h = bitmap.height
        if (w <= maxEdge && h <= maxEdge) return bitmap
        val scale = maxEdge.toFloat() / max(w, h).toFloat()
        val newW = max(1, (w * scale).toInt())
        val newH = max(1, (h * scale).toInt())
        return Bitmap.createScaledBitmap(bitmap, newW, newH, true)
    }

    suspend fun saveImageToDeviceGallery(
        context: Context,
        filePath: String,
        displayTitle: String
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val bitmap = loadBitmapFromPath(filePath)
                ?: return@withContext Result.failure(IllegalStateException("Archivo de imagen no encontrado."))
            saveBitmapToGallery(context, bitmap, displayTitle)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun saveBitmapToGallery(
        context: Context,
        bitmap: Bitmap,
        displayTitle: String
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val cleanName = displayTitle.replace(Regex("[^a-zA-Z0-9_\\-]"), "_").ifBlank { "luna_render" }
            val fileName = "${cleanName}_${System.currentTimeMillis()}.jpg"
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/Luna AI")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: return@withContext Result.failure(IllegalStateException("No se pudo crear archivo en la galería."))

            resolver.openOutputStream(uri)?.use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, out)
            } ?: return@withContext Result.failure(IllegalStateException("Error escribiendo la imagen."))

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                values.clear()
                values.put(MediaStore.Images.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
            }
            Result.success("Imagen guardada en Pictures/Luna AI ($fileName)")
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Synthesizes a playable H.264 MP4 video from the generated keyframe bitmaps using MediaCodec + MediaMuxer
     * and saves it to Movies/Luna AI. Falls back to saving all keyframe images if hardware H.264 encoding
     * is unavailable on the device.
     */
    suspend fun exportKeyframesVideoToDevice(
        context: Context,
        keyframePaths: List<String>,
        durationSec: Int,
        displayTitle: String
    ): Result<String> = withContext(Dispatchers.IO) {
        val bitmaps = keyframePaths.mapNotNull { loadBitmapFromPath(it) }
        if (bitmaps.isEmpty()) {
            return@withContext Result.failure(IllegalStateException("No hay fotogramas disponibles para exportar."))
        }

        val cleanName = displayTitle.replace(Regex("[^a-zA-Z0-9_\\-]"), "_").ifBlank { "luna_video" }
        val tempMp4 = File(context.cacheDir, "${cleanName}_${System.currentTimeMillis()}.mp4")

        val encodedOk = runCatching {
            encodeBitmapsToMp4(bitmaps, durationSec.coerceIn(5, 30), tempMp4)
        }.getOrDefault(false)

        if (encodedOk && tempMp4.exists() && tempMp4.length() > 1024L) {
            return@withContext runCatching {
                val fileName = "${cleanName}_${System.currentTimeMillis()}.mp4"
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/Luna AI")
                        put(MediaStore.Video.Media.IS_PENDING, 1)
                    }
                }
                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                    ?: error("No se pudo registrar el video en MediaStore.")

                resolver.openOutputStream(uri)?.use { out ->
                    tempMp4.inputStream().use { input -> input.copyTo(out) }
                } ?: error("Error copiando el archivo MP4.")

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    values.clear()
                    values.put(MediaStore.Video.Media.IS_PENDING, 0)
                    resolver.update(uri, values, null, null)
                }
                tempMp4.delete()
                "Video MP4 guardado en Movies/Luna AI ($fileName)"
            }
        } else {
            tempMp4.delete()
            // Reliable fallback: save every keyframe in high resolution to Pictures/Luna AI
            var savedCount = 0
            bitmaps.forEachIndexed { idx, bmp ->
                if (saveBitmapToGallery(context, bmp, "${cleanName}_frame_${idx + 1}").isSuccess) {
                    savedCount++
                }
            }
            if (savedCount > 0) {
                Result.success("$savedCount fotogramas HD guardados en Pictures/Luna AI")
            } else {
                Result.failure(IllegalStateException("No se pudo exportar el video en este dispositivo."))
            }
        }
    }

    private class MuxerState(var trackIndex: Int = -1, var started: Boolean = false)

    private fun encodeBitmapsToMp4(
        bitmaps: List<Bitmap>,
        durationSec: Int,
        outputFile: File
    ): Boolean {
        val width = 720
        val height = 1280
        val fps = 15
        val totalFrames = durationSec * fps
        val mime = MediaFormat.MIMETYPE_VIDEO_AVC

        val format = MediaFormat.createVideoFormat(mime, width, height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, 2_500_000)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }

        val encoder = MediaCodec.createEncoderByType(mime)
        encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val inputSurface = encoder.createInputSurface()
        encoder.start()

        val muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val muxerState = MuxerState()
        val bufferInfo = MediaCodec.BufferInfo()
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

        try {
            val framesPerClip = max(1, totalFrames / bitmaps.size)
            for (frameIdx in 0 until totalFrames) {
                val clipIndex = min(bitmaps.size - 1, frameIdx / framesPerClip)
                val localProgress = (frameIdx % framesPerClip).toFloat() / framesPerClip.toFloat()
                val bmp = bitmaps[clipIndex]

                val canvas: Canvas = inputSurface.lockCanvas(null)
                try {
                    canvas.drawColor(android.graphics.Color.BLACK)
                    val baseScale = max(width.toFloat() / bmp.width, height.toFloat() / bmp.height)
                    val kenBurnsScale = baseScale * (1f + 0.06f * localProgress)
                    val matrix = Matrix().apply {
                        postTranslate(-bmp.width / 2f, -bmp.height / 2f)
                        postScale(kenBurnsScale, kenBurnsScale)
                        postTranslate(width / 2f, height / 2f)
                    }
                    canvas.drawBitmap(bmp, matrix, paint)
                } finally {
                    inputSurface.unlockCanvasAndPost(canvas)
                }

                drainEncoder(encoder, muxer, bufferInfo, muxerState, endOfStream = false)
            }

            encoder.signalEndOfInputStream()
            drainEncoder(encoder, muxer, bufferInfo, muxerState, endOfStream = true)
            return muxerState.started && muxerState.trackIndex >= 0
        } finally {
            runCatching { encoder.stop() }
            runCatching { encoder.release() }
            runCatching { inputSurface.release() }
            if (muxerState.started) {
                runCatching { muxer.stop() }
            }
            runCatching { muxer.release() }
        }
    }

    private fun drainEncoder(
        encoder: MediaCodec,
        muxer: MediaMuxer,
        bufferInfo: MediaCodec.BufferInfo,
        muxerState: MuxerState,
        endOfStream: Boolean
    ) {
        val timeoutUs = if (endOfStream) 10_000L else 0L
        while (true) {
            val status = encoder.dequeueOutputBuffer(bufferInfo, timeoutUs)
            if (status == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!endOfStream) break
            } else if (status == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                if (!muxerState.started) {
                    muxerState.trackIndex = muxer.addTrack(encoder.outputFormat)
                    muxer.start()
                    muxerState.started = true
                }
            } else if (status >= 0) {
                val encodedData: ByteBuffer = encoder.getOutputBuffer(status) ?: continue
                if (bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) {
                    bufferInfo.size = 0
                }
                if (bufferInfo.size != 0 && muxerState.started) {
                    encodedData.position(bufferInfo.offset)
                    encodedData.limit(bufferInfo.offset + bufferInfo.size)
                    muxer.writeSampleData(muxerState.trackIndex, encodedData, bufferInfo)
                }
                encoder.releaseOutputBuffer(status, false)
                if (bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                    break
                }
            }
        }
    }
}

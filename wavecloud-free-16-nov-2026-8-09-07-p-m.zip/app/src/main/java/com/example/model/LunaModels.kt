package com.example.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@Keep
@IgnoreExtraProperties
data class LunaCharacter(
    @DocumentId val id: String = "",
    val userId: String = "",
    val codeName: String = "Luna-001",
    val seed: Long = 849201L,
    val description: String = "Musa digital editorial con cabello plateado-violeta luminiscente, iluminación neón cian sutil y estética cinematográfica 50mm.",
    val stylePreset: String = "Profesional",
    val selectedVariation: Long = 0L,
    val activeStatus: Boolean = true,
    val localImagePath: String = "",
    val variationPaths: List<String> = emptyList(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toCreateMap(uid: String): Map<String, Any> = mapOf(
        "userId" to uid,
        "codeName" to codeName.trim().ifBlank { "Luna-001" }.take(60),
        "seed" to seed.coerceAtLeast(0L),
        "description" to description.take(1000),
        "stylePreset" to stylePreset.take(40).ifBlank { "Profesional" },
        "selectedVariation" to selectedVariation.coerceIn(0L, 5L),
        "activeStatus" to activeStatus,
        "localImagePath" to localImagePath.take(300),
        "variationPaths" to variationPaths.take(6).map { it.take(300) },
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    )

    fun toUpdateMap(): Map<String, Any> = mapOf(
        "codeName" to codeName.trim().ifBlank { "Luna-001" }.take(60),
        "seed" to seed.coerceAtLeast(0L),
        "description" to description.take(1000),
        "stylePreset" to stylePreset.take(40).ifBlank { "Profesional" },
        "selectedVariation" to selectedVariation.coerceIn(0L, 5L),
        "activeStatus" to activeStatus,
        "localImagePath" to localImagePath.take(300),
        "variationPaths" to variationPaths.take(6).map { it.take(300) },
        "updatedAt" to FieldValue.serverTimestamp()
    )
}

@Keep
@IgnoreExtraProperties
data class VideoProject(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "Escena Nocturna",
    val topic: String = "",
    val cameraPrompt: String = "",
    val voiceoverScript: String = "",
    val durationSec: Long = 15L,
    val lookStyle: String = "Profesional",
    val cameraModel: String = "ARRI Alexa 35",
    val lens: String = "50 mm",
    val warmLightPct: Long = 35L,
    val grainPct: Long = 18L,
    val voiceName: String = "Luna Clara",
    val voicePace: String = "Natural",
    val status: String = "ready",
    val keyframePaths: List<String> = emptyList(),
    val referenceImagePath: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toCreateMap(uid: String): Map<String, Any> = mapOf(
        "userId" to uid,
        "title" to title.trim().ifBlank { "Proyecto Luna" }.take(120),
        "topic" to topic.take(300),
        "cameraPrompt" to cameraPrompt.take(1500),
        "voiceoverScript" to voiceoverScript.take(1500),
        "durationSec" to durationSec.coerceIn(5L, 30L),
        "lookStyle" to lookStyle.take(40).ifBlank { "Profesional" },
        "cameraModel" to cameraModel.take(60).ifBlank { "ARRI Alexa 35" },
        "lens" to lens.take(40).ifBlank { "50 mm" },
        "warmLightPct" to warmLightPct.coerceIn(0L, 100L),
        "grainPct" to grainPct.coerceIn(0L, 100L),
        "voiceName" to voiceName.take(40).ifBlank { "Luna Clara" },
        "voicePace" to voicePace.take(40).ifBlank { "Natural" },
        "status" to if (status in listOf("draft", "generating", "ready", "archived")) status else "ready",
        "keyframePaths" to keyframePaths.take(8).map { it.take(300) },
        "referenceImagePath" to referenceImagePath.take(300),
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    )
}

@Keep
@IgnoreExtraProperties
data class GeneratedMedia(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "",
    val prompt: String = "",
    val mediaType: String = "image",
    val modelUsed: String = "gemini-nano-banana-2.1",
    val aspectRatio: String = "1:1",
    val styleLook: String = "Profesional",
    val seed: Long = 0L,
    val favorite: Boolean = false,
    val localFilePath: String = "",
    val projectId: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toCreateMap(uid: String): Map<String, Any> = mapOf(
        "userId" to uid,
        "title" to title.trim().ifBlank { "Creación Luna AI" }.take(120),
        "prompt" to prompt.trim().ifBlank { "Escena generada con Luna AI" }.take(1500),
        "mediaType" to if (mediaType in listOf("image", "video", "character")) mediaType else "image",
        "modelUsed" to modelUsed.take(60).ifBlank { "gemini-nano-banana-2.1" },
        "aspectRatio" to aspectRatio.take(20).ifBlank { "1:1" },
        "styleLook" to styleLook.take(40).ifBlank { "Profesional" },
        "seed" to seed.coerceAtLeast(0L),
        "favorite" to favorite,
        "localFilePath" to localFilePath.take(300),
        "projectId" to projectId.take(128),
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    )
}

data class VideoDirectionDraft(
    val title: String,
    val cameraPrompt: String,
    val voiceoverScript: String,
    val keyframePrompts: List<String>
)

data class CharacterConceptDraft(
    val codeName: String,
    val description: String,
    val seed: Long
)

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

sealed interface GenerationProgress {
    data object Idle : GenerationProgress
    data class Working(val stage: String, val progress: Float) : GenerationProgress
    data class Completed(val message: String) : GenerationProgress
    data class Error(val message: String) : GenerationProgress
}

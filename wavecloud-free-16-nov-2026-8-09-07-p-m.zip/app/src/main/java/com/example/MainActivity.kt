package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.core.configureAppCheck
import com.example.ui.auth.AuthScreen
import com.example.ui.auth.authStateFlow
import com.example.ui.components.LunaBottomBar
import com.example.ui.screens.CharactersScreen
import com.example.ui.screens.GalleryScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ImageStudioScreen
import com.example.ui.screens.VideoPlayerScreen
import com.example.ui.screens.VideoStudioScreen
import com.example.ui.theme.LunaAiTheme
import com.example.ui.theme.MidnightBg
import com.example.ui.viewmodel.LunaStudioViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.auth

const val ROUTE_HOME = "home"
const val ROUTE_VIDEO_STUDIO = "video_studio"
const val ROUTE_IMAGE_STUDIO = "image_studio"
const val ROUTE_CHARACTERS = "characters"
const val ROUTE_GALLERY = "gallery"
const val ROUTE_VIDEO_PLAYER = "video_player"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Configure Firebase App Check with launch intent before rendering UI or creating ViewModels
        configureAppCheck(this, intent)

        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(MidnightBg.toArgb()),
            navigationBarStyle = SystemBarStyle.dark(MidnightBg.toArgb())
        )

        setContent {
            LunaAiTheme {
                AppNavigation()
            }
        }
    }
}

@Composable
fun AppNavigation() {
    val auth = Firebase.auth
    val currentUser by auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)
    val user = currentUser

    if (user == null) {
        AuthScreen(onAuthSuccess = {})
    } else {
        key(user.uid) {
            LunaAuthenticatedShell(currentUserId = user.uid)
        }
    }
}

@Composable
private fun LunaAuthenticatedShell(currentUserId: String) {
    val context = LocalContext.current
    val viewModel: LunaStudioViewModel = viewModel(
        key = currentUserId,
        factory = LunaStudioViewModel.provideFactory(currentUserId)
    )

    LaunchedEffect(currentUserId) {
        viewModel.initializeStarterAssets(context)
    }

    val charactersState by viewModel.charactersState.collectAsStateWithLifecycle()
    val projectsState by viewModel.projectsState.collectAsStateWithLifecycle()
    val generationsState by viewModel.generationsState.collectAsStateWithLifecycle()
    val activeVideoProject by viewModel.activeVideoProject.collectAsStateWithLifecycle()
    val snackbarMessage by viewModel.snackbarMessage.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(snackbarMessage) {
        val msg = snackbarMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.consumeSnackbar()
        }
    }

    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: ROUTE_HOME

    val navigateTab: (String) -> Unit = { route ->
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    Scaffold(
        containerColor = MidnightBg,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        bottomBar = {
            if (currentRoute != ROUTE_VIDEO_PLAYER) {
                LunaBottomBar(
                    currentRoute = currentRoute,
                    onNavigate = navigateTab
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MidnightBg)
                .windowInsetsPadding(WindowInsets.statusBars)
                .padding(bottom = innerPadding.calculateBottomPadding())
        ) {
            NavHost(
                navController = navController,
                startDestination = ROUTE_HOME,
                modifier = Modifier.fillMaxSize()
            ) {
                composable(ROUTE_HOME) {
                    HomeScreen(
                        charactersState = charactersState,
                        projectsState = projectsState,
                        generationsState = generationsState,
                        onNavigateToImageStudio = { navigateTab(ROUTE_IMAGE_STUDIO) },
                        onNavigateToVideoStudio = { navigateTab(ROUTE_VIDEO_STUDIO) },
                        onNavigateToCharacters = { navigateTab(ROUTE_CHARACTERS) },
                        onNavigateToGallery = { navigateTab(ROUTE_GALLERY) },
                        onOpenVideoProject = { proj ->
                            viewModel.openVideoProject(proj)
                            navController.navigate(ROUTE_VIDEO_PLAYER)
                        }
                    )
                }

                composable(ROUTE_VIDEO_STUDIO) {
                    VideoStudioScreen(
                        viewModel = viewModel,
                        onOpenVideoPlayer = { proj ->
                            viewModel.openVideoProject(proj)
                            navController.navigate(ROUTE_VIDEO_PLAYER)
                        }
                    )
                }

                composable(ROUTE_IMAGE_STUDIO) {
                    ImageStudioScreen(
                        viewModel = viewModel,
                        onSendToVideoStudio = { navigateTab(ROUTE_VIDEO_STUDIO) }
                    )
                }

                composable(ROUTE_CHARACTERS) {
                    CharactersScreen(
                        viewModel = viewModel,
                        charactersState = charactersState
                    )
                }

                composable(ROUTE_GALLERY) {
                    GalleryScreen(
                        generationsState = generationsState,
                        projectsState = projectsState,
                        viewModel = viewModel,
                        onOpenVideoProject = { proj ->
                            viewModel.openVideoProject(proj)
                            navController.navigate(ROUTE_VIDEO_PLAYER)
                        }
                    )
                }

                composable(ROUTE_VIDEO_PLAYER) {
                    VideoPlayerScreen(
                        project = activeVideoProject,
                        viewModel = viewModel,
                        onBack = { navController.popBackStack() },
                        onEditProject = { proj ->
                            viewModel.loadProjectIntoEditor(proj)
                            navController.popBackStack()
                            navigateTab(ROUTE_VIDEO_STUDIO)
                        }
                    )
                }
            }
        }
    }
}

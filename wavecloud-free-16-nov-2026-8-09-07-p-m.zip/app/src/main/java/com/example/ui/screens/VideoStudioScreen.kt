package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.MovieCreation
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.RecordVoiceOver
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.R
import com.example.core.VoicePreviewPlayer
import com.example.model.GenerationProgress
import com.example.model.VideoProject
import com.example.ui.components.GenerationStatusBanner
import com.example.ui.components.LunaCollapsibleSection
import com.example.ui.components.LunaGlassCard
import com.example.ui.components.LunaGradientButton
import com.example.ui.components.LunaLogo
import com.example.ui.theme.AmberWarm
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.GlassCardElevated
import com.example.ui.theme.MidnightBg
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.SubtleBorderViolet
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.LunaStudioViewModel
import java.io.File

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun VideoStudioScreen(
    viewModel: LunaStudioViewModel,
    onOpenVideoPlayer: (VideoProject) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val draft by viewModel.videoDraft.collectAsStateWithLifecycle()
    val progress by viewModel.videoProgress.collectAsStateWithLifecycle()
    val uploadProgress by viewModel.uploadProgress.collectAsStateWithLifecycle()
    val activeProject by viewModel.activeVideoProject.collectAsStateWithLifecycle()

    val voicePlayer = remember { VoicePreviewPlayer(context) }
    val isSpeaking by voicePlayer.isSpeaking.collectAsStateWithLifecycle()
    DisposableEffect(Unit) {
        onDispose { voicePlayer.release() }
    }

    var cameraExpanded by remember { mutableStateOf(true) }
    var voiceExpanded by remember { mutableStateOf(true) }
    var settingsExpanded by remember { mutableStateOf(true) }
    var galleryExpanded by remember { mutableStateOf(true) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        uri?.let { viewModel.pickVideoReference(context, it) }
    }

    val isBusy = progress is GenerationProgress.Working

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MidnightBg),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 640.dp),
            contentPadding = PaddingValues(horizontal = 18.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        LunaLogo(size = 36.dp)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = stringResource(R.string.video_studio_title),
                                style = MaterialTheme.typography.headlineMedium,
                                color = TextPrimary
                            )
                            Text(
                                text = "Dirección y Ajustes de Toma • Cloud AI",
                                style = MaterialTheme.typography.labelSmall,
                                color = NeonCyan
                            )
                        }
                    }

                    if (activeProject != null && activeProject!!.keyframePaths.isNotEmpty()) {
                        OutlinedButton(
                            onClick = { onOpenVideoPlayer(activeProject!!) },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("open_latest_video_button")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.PlayArrow,
                                contentDescription = "Ver resultado",
                                tint = NeonCyan,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Ver video", color = TextPrimary)
                        }
                    }
                }
            }

            // Tema o Explicación + (0/300) + Inspiración
            item {
                LunaGlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = stringResource(R.string.topic_label),
                                style = MaterialTheme.typography.titleMedium,
                                color = TextPrimary
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "${draft.topic.length}/300",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = if (draft.topic.length >= 280) AmberWarm else TextSecondary
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                IconButton(
                                    onClick = { viewModel.inspireVideoTopic() },
                                    enabled = !isBusy,
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(ElectricViolet.copy(alpha = 0.2f))
                                        .testTag("inspire_topic_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.AutoAwesome,
                                        contentDescription = "Inspiración de tema IA",
                                        tint = NeonCyan
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedTextField(
                            value = draft.topic,
                            onValueChange = { input ->
                                if (input.length <= 300) {
                                    viewModel.updateVideoDraft { it.copy(topic = input) }
                                }
                            },
                            placeholder = {
                                Text(
                                    "Describe la escena, historia o producto que quieres dirigir...",
                                    color = TextMuted
                                )
                            },
                            minLines = 3,
                            maxLines = 5,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NeonCyan,
                                unfocusedBorderColor = SubtleBorderViolet,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary,
                                cursorColor = NeonCyan
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("video_topic_input")
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        LunaGradientButton(
                            text = stringResource(R.string.assemble_direction),
                            onClick = { viewModel.assembleVideoDirection() },
                            enabled = !isBusy,
                            icon = Icons.Rounded.AutoAwesome,
                            gradientColors = listOf(ElectricViolet, NeonCyan),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("assemble_direction_button")
                        )
                    }
                }
            }

            // Progress / Status Banner
            item {
                GenerationStatusBanner(
                    progress = progress,
                    onDismiss = { viewModel.resetVideoProgress() }
                )
            }

            // Collapsible: Prompt de Cámara
            item {
                LunaCollapsibleSection(
                    title = stringResource(R.string.camera_prompt_title),
                    subtitle = "${draft.cameraModel} • ${draft.lens}",
                    icon = Icons.Rounded.CameraAlt,
                    expanded = cameraExpanded,
                    onToggle = { cameraExpanded = !cameraExpanded },
                    testTag = "section_camera_prompt"
                ) {
                    OutlinedTextField(
                        value = draft.cameraPrompt,
                        onValueChange = { txt ->
                            viewModel.updateVideoDraft { it.copy(cameraPrompt = txt.take(1500)) }
                        },
                        placeholder = {
                            Text("Ángulo, movimiento de cámara, iluminación y atmósfera...", color = TextMuted)
                        },
                        minLines = 2,
                        maxLines = 4,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonCyan,
                            unfocusedBorderColor = SubtleBorderViolet,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("camera_prompt_input")
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("Travelling lento", "Plano cenital", "Contrapicado épico", "Orbital 360°").forEach { cue ->
                            FilterChip(
                                selected = draft.cameraPrompt.contains(cue, ignoreCase = true),
                                onClick = {
                                    val updated = if (draft.cameraPrompt.isBlank()) cue
                                    else "${draft.cameraPrompt.trimEnd('.', ' ')}. $cue"
                                    viewModel.updateVideoDraft { it.copy(cameraPrompt = updated.take(1500)) }
                                },
                                label = { Text(cue, style = MaterialTheme.typography.bodySmall) },
                                colors = FilterChipDefaults.filterChipColors(
                                    containerColor = MidnightBg,
                                    labelColor = TextSecondary,
                                    selectedContainerColor = NeonCyan.copy(alpha = 0.22f),
                                    selectedLabelColor = NeonCyan
                                )
                            )
                        }
                    }
                }
            }

            // Collapsible: Voz en Off + Escuchar voz
            item {
                LunaCollapsibleSection(
                    title = stringResource(R.string.voiceover_title),
                    subtitle = "${draft.voiceName} • Ritmo ${draft.voicePace}",
                    icon = Icons.Rounded.RecordVoiceOver,
                    expanded = voiceExpanded,
                    onToggle = { voiceExpanded = !voiceExpanded },
                    testTag = "section_voiceover"
                ) {
                    OutlinedTextField(
                        value = draft.voiceoverScript,
                        onValueChange = { txt ->
                            viewModel.updateVideoDraft { it.copy(voiceoverScript = txt.take(1500)) }
                        },
                        placeholder = {
                            Text("Guion de narración para tu escena...", color = TextMuted)
                        },
                        minLines = 2,
                        maxLines = 4,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonCyan,
                            unfocusedBorderColor = SubtleBorderViolet,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("voiceover_script_input")
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = {
                            if (isSpeaking) {
                                voicePlayer.stop()
                            } else {
                                val textToSpeak = draft.voiceoverScript.ifBlank {
                                    "Bienvenido a Luna AI. Tu escena está lista para cobrar vida."
                                }
                                voicePlayer.speak(textToSpeak, draft.voiceName, draft.voicePace)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = GlassCardElevated,
                            contentColor = NeonCyan
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("listen_voice_button")
                    ) {
                        Icon(
                            imageVector = if (isSpeaking) Icons.Rounded.Stop else Icons.Rounded.GraphicEq,
                            contentDescription = null,
                            tint = NeonCyan
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isSpeaking) "Detener audio" else stringResource(R.string.listen_voice),
                            color = TextPrimary
                        )
                    }
                }
            }

            // Collapsible: Ajustes de toma
            item {
                LunaCollapsibleSection(
                    title = stringResource(R.string.shot_settings_title),
                    subtitle = "${draft.durationSec}s • ${draft.lookStyle} • ${draft.lens}",
                    icon = Icons.Rounded.Tune,
                    expanded = settingsExpanded,
                    onToggle = { settingsExpanded = !settingsExpanded },
                    testTag = "section_shot_settings"
                ) {
                    // Duración (5s - 30s, default 15s)
                    SettingSliderRow(
                        label = "Duración",
                        valueText = "${draft.durationSec}s",
                        value = draft.durationSec.toFloat(),
                        range = 5f..30f,
                        onValueChange = { v ->
                            viewModel.updateVideoDraft { it.copy(durationSec = v.toInt()) }
                        }
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    Text("Estilo / Look", style = MaterialTheme.typography.titleSmall, color = TextPrimary)
                    Spacer(modifier = Modifier.height(6.dp))
                    ChipSelectorRow(
                        options = listOf("Profesional", "Surreal", "Natural", "Real"),
                        selected = draft.lookStyle,
                        onSelect = { style -> viewModel.updateVideoDraft { it.copy(lookStyle = style) } }
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Cámara", style = MaterialTheme.typography.titleSmall, color = TextPrimary)
                    Spacer(modifier = Modifier.height(6.dp))
                    ChipSelectorRow(
                        options = listOf("ARRI Alexa 35", "RED V-Raptor", "Sony Venice 2", "IMAX 70mm"),
                        selected = draft.cameraModel,
                        onSelect = { cam -> viewModel.updateVideoDraft { it.copy(cameraModel = cam) } }
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Lente", style = MaterialTheme.typography.titleSmall, color = TextPrimary)
                    Spacer(modifier = Modifier.height(6.dp))
                    ChipSelectorRow(
                        options = listOf("24 mm", "35 mm", "50 mm", "85 mm Anamórfico"),
                        selected = draft.lens,
                        onSelect = { lens -> viewModel.updateVideoDraft { it.copy(lens = lens) } }
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    SettingSliderRow(
                        label = "Luz cálida",
                        valueText = "${draft.warmLightPct}%",
                        value = draft.warmLightPct.toFloat(),
                        range = 0f..100f,
                        onValueChange = { v ->
                            viewModel.updateVideoDraft { it.copy(warmLightPct = v.toInt()) }
                        }
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    SettingSliderRow(
                        label = "Grano fílmico",
                        valueText = "${draft.grainPct}%",
                        value = draft.grainPct.toFloat(),
                        range = 0f..100f,
                        onValueChange = { v ->
                            viewModel.updateVideoDraft { it.copy(grainPct = v.toInt()) }
                        }
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Voice", style = MaterialTheme.typography.titleSmall, color = TextPrimary)
                    Spacer(modifier = Modifier.height(6.dp))
                    ChipSelectorRow(
                        options = listOf("Luna Clara", "Orion Grave", "Aura Editorial", "Echo Dinámico"),
                        selected = draft.voiceName,
                        onSelect = { voice -> viewModel.updateVideoDraft { it.copy(voiceName = voice) } }
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Ritmo de voz", style = MaterialTheme.typography.titleSmall, color = TextPrimary)
                    Spacer(modifier = Modifier.height(6.dp))
                    ChipSelectorRow(
                        options = listOf("Pausado", "Natural", "Dinámico", "Cinematográfico"),
                        selected = draft.voicePace,
                        onSelect = { pace -> viewModel.updateVideoDraft { it.copy(voicePace = pace) } }
                    )
                }
            }

            // Collapsible: Foto de la galería (Image-to-Video)
            item {
                LunaCollapsibleSection(
                    title = stringResource(R.string.gallery_photo_title),
                    subtitle = if (draft.referenceImagePath.isNotBlank()) "Imagen de referencia cargada" else "Opcional • Image-to-Video",
                    icon = Icons.Rounded.Image,
                    expanded = galleryExpanded,
                    onToggle = { galleryExpanded = !galleryExpanded },
                    testTag = "section_gallery_photo"
                ) {
                    if (uploadProgress != null) {
                        LinearProgressIndicator(
                            progress = { uploadProgress ?: 0.5f },
                            color = NeonCyan,
                            trackColor = MidnightBg,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 10.dp)
                        )
                    }

                    if (draft.referenceImagePath.isNotBlank() && File(draft.referenceImagePath).exists()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(150.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .border(1.dp, NeonCyan.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                        ) {
                            AsyncImage(
                                model = File(draft.referenceImagePath),
                                contentDescription = "Imagen de referencia",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                            IconButton(
                                onClick = { viewModel.updateVideoDraft { it.copy(referenceImagePath = "") } },
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(6.dp)
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(50))
                                    .background(MidnightBg.copy(alpha = 0.8f))
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Close,
                                    contentDescription = "Quitar referencia",
                                    tint = TextPrimary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                    }

                    OutlinedButton(
                        onClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("select_video_reference_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.UploadFile,
                            contentDescription = null,
                            tint = NeonCyan
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = stringResource(R.string.select_file),
                            color = TextPrimary
                        )
                    }
                }
            }

            // Execute Create Video Button
            item {
                LunaGradientButton(
                    text = if (isBusy) "Generando secuencia en la nube..." else stringResource(R.string.execute_create_video),
                    onClick = {
                        viewModel.createCloudVideo(context) { createdProject ->
                            onOpenVideoPlayer(createdProject)
                        }
                    },
                    enabled = !isBusy,
                    icon = Icons.Rounded.MovieCreation,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("create_video_button")
                )
            }

            item { Spacer(modifier = Modifier.height(12.dp)) }
        }
    }
}

@Composable
private fun SettingSliderRow(
    label: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(label, style = MaterialTheme.typography.titleSmall, color = TextPrimary)
            Text(valueText, style = MaterialTheme.typography.labelMedium, color = NeonCyan)
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = NeonCyan,
                activeTrackColor = NeonCyan,
                inactiveTrackColor = MidnightBg
            )
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ChipSelectorRow(
    options: List<String>,
    selected: String,
    onSelect: (String) -> Unit
) {
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        options.forEach { option ->
            val isSelected = option == selected
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        if (isSelected) NeonCyan.copy(alpha = 0.2f) else MidnightBg.copy(alpha = 0.7f)
                    )
                    .border(
                        width = 1.dp,
                        color = if (isSelected) NeonCyan else SubtleBorderViolet,
                        shape = RoundedCornerShape(12.dp)
                    )
                    .clickable { onSelect(option) }
                    .padding(horizontal = 12.dp, vertical = 9.dp)
            ) {
                Text(
                    text = option,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (isSelected) NeonCyan else TextSecondary
                )
            }
        }
    }
}

package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val LunaDarkColorScheme = darkColorScheme(
    primary = NeonCyan,
    onPrimary = MidnightBg,
    primaryContainer = DeepIndigo,
    onPrimaryContainer = TextPrimary,
    secondary = ElectricViolet,
    onSecondary = TextPrimary,
    secondaryContainer = GlassCardElevated,
    onSecondaryContainer = TextPrimary,
    tertiary = MagentaAccent,
    onTertiary = TextPrimary,
    background = MidnightBg,
    onBackground = TextPrimary,
    surface = ObsidianSurface,
    onSurface = TextPrimary,
    surfaceVariant = GlassCardBg,
    onSurfaceVariant = TextSecondary,
    outline = SubtleBorderViolet,
    outlineVariant = SurfaceDivider,
    error = MagentaAccent,
    onError = TextPrimary
)

val LunaShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun LunaAiTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = LunaDarkColorScheme,
        typography = Typography,
        shapes = LunaShapes,
        content = content
    )
}

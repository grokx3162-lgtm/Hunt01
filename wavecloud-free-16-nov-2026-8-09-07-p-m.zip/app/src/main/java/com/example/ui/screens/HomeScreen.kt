package com.example.ui.screens

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CloudDone
import androidx.compose.material.icons.rounded.Collections
import androidx.compose.material.icons.rounded.FaceRetouchingNatural
import androidx.compose.material.icons.rounded.MovieCreation
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.R
import com.example.model.GeneratedMedia
import com.example.model.LunaCharacter
import com.example.model.UiState
import com.example.model.VideoProject
import com.example.ui.components.LunaGlassCard
import com.example.ui.components.LunaGradientButton
import com.example.ui.components.LunaLogo
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.EmeraldActive
import com.example.ui.theme.GlassCardElevated
import com.example.ui.theme.MidnightBg
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    charactersState: UiState<List<LunaCharacter>>,
    projectsState: UiState<List<VideoProject>>,
    generationsState: UiState<List<GeneratedMedia>>,
    onNavigateToImageStudio: () -> Unit,
    onNavigateToVideoStudio: () -> Unit,
    onNavigateToCharacters: () -> Unit,
    onNavigateToGallery: () -> Unit,
    onOpenVideoProject: (VideoProject) -> Unit,
    modifier: Modifier = Modifier
) {
    var showCreateSheet by remember { mutableStateOf(false) }

    val activeCharacter = remember(charactersState) {
        (charactersState as? UiState.Success)?.data?.firstOrNull { it.activeStatus }
            ?: (charactersState as? UiState.Success)?.data?.firstOrNull()
    }
    val recentProjects = remember(projectsState) {
        (projectsState as? UiState.Success)?.data.orEmpty()
    }
    val recentMedia = remember(generationsState) {
        (generationsState as? UiState.Success)?.data.orEmpty()
    }

    val pulseTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by pulseTransition.animateFloat(
        initialValue = 0.45f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1100),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MidnightBg),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 640.dp),
            contentPadding = PaddingValues(horizontal = 18.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        LunaLogo(size = 44.dp)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = stringResource(R.string.app_name),
                                style = MaterialTheme.typography.headlineMedium,
                                color = TextPrimary
                            )
                            Text(
                                text = stringResource(R.string.app_tagline),
                                style = MaterialTheme.typography.labelMedium,
                                color = NeonCyan
                            )
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(GlassCardElevated)
                            .border(1.dp, EmeraldActive.copy(alpha = 0.4f), RoundedCornerShape(50))
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.CloudDone,
                            contentDescription = "Nube activa",
                            tint = EmeraldActive,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = "Nube Gratis",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextPrimary
                        )
                    }
                }
            }

            // Hero Banner con personaje IA
            item {
                LunaGlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigateToCharacters() },
                    cornerRadius = 24.dp
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(210.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_luna_hero),
                            contentDescription = "Banner principal Luna AI",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(
                                            Color.Transparent,
                                            MidnightBg.copy(alpha = 0.35f),
                                            MidnightBg.copy(alpha = 0.92f)
                                        )
                                    )
                                )
                        )
                        Row(
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(14.dp)
                                .clip(RoundedCornerShape(50))
                                .background(MidnightBg.copy(alpha = 0.72f))
                                .border(1.dp, NeonCyan.copy(alpha = 0.45f), RoundedCornerShape(50))
                                .padding(horizontal = 10.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.AutoAwesome,
                                contentDescription = null,
                                tint = NeonCyan,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = "WaveSpeed Cloud • Nano Banana 2.1",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextPrimary
                            )
                        }

                        Column(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(16.dp)
                        ) {
                            Text(
                                text = "Estudio Creativo Multimodal",
                                style = MaterialTheme.typography.titleLarge,
                                color = TextPrimary
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Genera imágenes 2K, personajes IA y dirección de video gratis en la nube.",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                                maxLines = 2
                            )
                        }
                    }
                }
            }

            // Primary CTA "+ Crear nuevo"
            item {
                LunaGradientButton(
                    text = stringResource(R.string.create_new),
                    onClick = { showCreateSheet = true },
                    icon = Icons.Rounded.Add,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("create_new_button")
                )
            }

            // 2x2 Interactive Shortcut Grid
            item {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        ShortcutTile(
                            title = stringResource(R.string.shortcut_generate_image),
                            subtitle = "Texto e Image-to-Image",
                            icon = Icons.Rounded.AutoAwesome,
                            accentColor = NeonCyan,
                            onClick = onNavigateToImageStudio,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("shortcut_generate_image")
                        )
                        ShortcutTile(
                            title = stringResource(R.string.shortcut_generate_video),
                            subtitle = "Dirección y Toma Pro",
                            icon = Icons.Rounded.MovieCreation,
                            accentColor = ElectricViolet,
                            onClick = onNavigateToVideoStudio,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("shortcut_generate_video")
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        ShortcutTile(
                            title = stringResource(R.string.shortcut_ai_characters),
                            subtitle = "100% IA • Sin reales",
                            icon = Icons.Rounded.FaceRetouchingNatural,
                            accentColor = ElectricViolet,
                            onClick = onNavigateToCharacters,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("shortcut_ai_characters")
                        )
                        ShortcutTile(
                            title = stringResource(R.string.shortcut_gallery),
                            subtitle = "${recentMedia.size} creaciones",
                            icon = Icons.Rounded.Collections,
                            accentColor = NeonCyan,
                            onClick = onNavigateToGallery,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("shortcut_gallery")
                        )
                    }
                }
            }

            // Current Active Project / Character Card ("Luna-001 - Personaje IA • Activa")
            item {
                val charTitle = activeCharacter?.codeName ?: "Luna-001"
                LunaGlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("active_character_card")
                        .clickable { onNavigateToCharacters() }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val imageFile = activeCharacter?.localImagePath?.takeIf { it.isNotBlank() && File(it).exists() }
                        if (imageFile != null) {
                            AsyncImage(
                                model = File(imageFile),
                                contentDescription = charTitle,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(58.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .border(1.dp, NeonCyan.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                            )
                        } else {
                            Image(
                                painter = painterResource(id = R.drawable.img_luna_character),
                                contentDescription = charTitle,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(58.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .border(1.dp, NeonCyan.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                            )
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .alpha(pulseAlpha)
                                        .clip(CircleShape)
                                        .background(EmeraldActive)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "$charTitle - Personaje IA • Activa",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = activeCharacter?.description?.ifBlank { null }
                                    ?: "Identidad sintética lista para escenas y retratos 50mm.",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        Spacer(modifier = Modifier.width(8.dp))
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowForward,
                            contentDescription = "Abrir personaje",
                            tint = NeonCyan
                        )
                    }
                }
            }

            // Recent Video Projects Strip
            if (recentProjects.isNotEmpty()) {
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "Proyectos de Video Recientes",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary
                        )
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(recentProjects, key = { it.id }) { project ->
                                LunaGlassCard(
                                    modifier = Modifier
                                        .width(168.dp)
                                        .clickable { onOpenVideoProject(project) },
                                    cornerRadius = 16.dp
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .aspectRatio(16f / 10f)
                                            .background(ObsidianSurface)
                                    ) {
                                        val thumb = project.keyframePaths.firstOrNull()?.takeIf { File(it).exists() }
                                        if (thumb != null) {
                                            AsyncImage(
                                                model = File(thumb),
                                                contentDescription = project.title,
                                                contentScale = ContentScale.Crop,
                                                modifier = Modifier.fillMaxSize()
                                            )
                                        }
                                        Box(
                                            modifier = Modifier
                                                .align(Alignment.Center)
                                                .size(34.dp)
                                                .clip(CircleShape)
                                                .background(MidnightBg.copy(alpha = 0.72f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Rounded.PlayArrow,
                                                contentDescription = "Reproducir",
                                                tint = NeonCyan,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text(
                                            text = project.title,
                                            style = MaterialTheme.typography.titleSmall,
                                            color = TextPrimary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = "${project.durationSec}s • ${project.lookStyle}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = TextSecondary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(8.dp)) }
        }
    }

    if (showCreateSheet) {
        ModalBottomSheet(
            onDismissRequest = { showCreateSheet = false },
            containerColor = ObsidianSurface,
            contentColor = TextPrimary
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "¿Qué deseas crear hoy?",
                    style = MaterialTheme.typography.headlineSmall,
                    color = TextPrimary
                )
                CreateSheetOption(
                    title = "Generar imagen en la nube",
                    subtitle = "Texto a imagen o edición con referencia (Nano Banana 2.1 / Pro)",
                    icon = Icons.Rounded.AutoAwesome,
                    onClick = {
                        showCreateSheet = false
                        onNavigateToImageStudio()
                    }
                )
                CreateSheetOption(
                    title = "Crear video con dirección IA",
                    subtitle = "Guion de cámara, voz en off, ajustes de toma y fotogramas clave",
                    icon = Icons.Rounded.MovieCreation,
                    onClick = {
                        showCreateSheet = false
                        onNavigateToVideoStudio()
                    }
                )
                CreateSheetOption(
                    title = "Diseñar personaje IA original",
                    subtitle = "Identidad sintética 100% IA con semilla y variaciones faciales",
                    icon = Icons.Rounded.FaceRetouchingNatural,
                    onClick = {
                        showCreateSheet = false
                        onNavigateToCharacters()
                    }
                )
                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}

@Composable
private fun ShortcutTile(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    LunaGlassCard(
        modifier = modifier.clickable(onClick = onClick),
        cornerRadius = 18.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(accentColor.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = accentColor,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun CreateSheetOption(
    title: String,
    subtitle: String,
    icon: ImageVector,
    onClick: () -> Unit
) {
    LunaGlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        cornerRadius = 16.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(NeonCyan.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = NeonCyan,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
        }
    }
}

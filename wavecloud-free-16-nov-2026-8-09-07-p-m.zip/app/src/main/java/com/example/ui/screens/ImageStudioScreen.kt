package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Casino
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.MovieCreation
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.R
import com.example.model.GenerationProgress
import com.example.ui.components.GenerationStatusBanner
import com.example.ui.components.LunaGlassCard
import com.example.ui.components.LunaGradientButton
import com.example.ui.components.LunaLogo
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.MidnightBg
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.SubtleBorderViolet
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.LunaStudioViewModel
import java.io.File
import kotlin.random.Random

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ImageStudioScreen(
    viewModel: LunaStudioViewModel,
    onSendToVideoStudio: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val draft by viewModel.imageDraft.collectAsStateWithLifecycle()
    val progress by viewModel.imageProgress.collectAsStateWithLifecycle()

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        uri?.let { viewModel.pickImageReference(context, it) }
    }

    val isBusy = progress is GenerationProgress.Working

    val models = listOf(
        "gemini-nano-banana-2.1" to "Nano Banana 2.1",
        "gemini-3-pro-image" to "Nano Banana Pro",
        "gemini-3.1-flash-lite-image" to "Nano Banana 2 Lite"
    )
    val ratios = listOf("1:1", "16:9", "9:16", "3:4", "4:3")
    val resolutions = listOf("1K", "2K")
    val styles = listOf("Profesional", "Surreal", "Natural", "Real", "Cyberpunk", "Editorial")

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MidnightBg),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 640.dp),
            contentPadding = PaddingValues(horizontal = 18.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    LunaLogo(size = 36.dp)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Generar imagen",
                            style = MaterialTheme.typography.headlineMedium,
                            color = TextPrimary
                        )
                        Text(
                            text = "Text-to-Image & Image-to-Image • Gratis en la nube",
                            style = MaterialTheme.typography.labelSmall,
                            color = NeonCyan
                        )
                    }
                }
            }

            // Prompt Card
            item {
                LunaGlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Prompt Creativo", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                            OutlinedButton(
                                onClick = { viewModel.enhanceImagePrompt() },
                                enabled = !isBusy,
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                modifier = Modifier.testTag("enhance_prompt_button")
                            ) {
                                Icon(Icons.Rounded.AutoAwesome, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Mejorar IA", style = MaterialTheme.typography.labelSmall, color = NeonCyan)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = draft.prompt,
                            onValueChange = { txt -> viewModel.updateImageDraft { it.copy(prompt = txt.take(1200)) } },
                            placeholder = {
                                Text("Ej: Astronauta contemplando una luna de neón sobre un océano bioluminiscente...", color = TextMuted)
                            },
                            minLines = 3,
                            maxLines = 5,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NeonCyan,
                                unfocusedBorderColor = SubtleBorderViolet,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("image_prompt_input")
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Reference image for Image-to-Image
                        if (draft.referenceImagePath.isNotBlank() && File(draft.referenceImagePath).exists()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(120.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .border(1.dp, NeonCyan.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                            ) {
                                AsyncImage(
                                    model = File(draft.referenceImagePath),
                                    contentDescription = "Referencia",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                                IconButton(
                                    onClick = { viewModel.updateImageDraft { it.copy(referenceImagePath = "") } },
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .padding(4.dp)
                                        .background(MidnightBg.copy(alpha = 0.75f), RoundedCornerShape(50))
                                ) {
                                    Icon(Icons.Rounded.Close, contentDescription = "Quitar", tint = TextPrimary)
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                        }

                        OutlinedButton(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("pick_image_ref_button")
                        ) {
                            Icon(Icons.Rounded.UploadFile, contentDescription = null, tint = NeonCyan)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (draft.referenceImagePath.isBlank()) "Subir referencia (Image-to-Image)" else "Cambiar referencia",
                                color = TextPrimary
                            )
                        }
                    }
                }
            }

            // WaveSpeed-style Model, Aspect Ratio, Resolution, Style & Seed Controls
            item {
                LunaGlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("Modelo en la nube", style = MaterialTheme.typography.titleSmall, color = TextPrimary)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            models.forEach { (id, label) ->
                                OptionChip(
                                    label = label,
                                    selected = draft.modelId == id,
                                    onClick = { viewModel.updateImageDraft { it.copy(modelId = id) } }
                                )
                            }
                        }

                        Text("Relación de aspecto", style = MaterialTheme.typography.titleSmall, color = TextPrimary)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            ratios.forEach { r ->
                                OptionChip(
                                    label = r,
                                    selected = draft.aspectRatio == r,
                                    onClick = { viewModel.updateImageDraft { it.copy(aspectRatio = r) } }
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Resolución", style = MaterialTheme.typography.titleSmall, color = TextPrimary)
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    resolutions.forEach { res ->
                                        OptionChip(
                                            label = res,
                                            selected = draft.resolution == res,
                                            onClick = { viewModel.updateImageDraft { it.copy(resolution = res) } }
                                        )
                                    }
                                }
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Seed", style = MaterialTheme.typography.titleSmall, color = TextPrimary)
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(MidnightBg)
                                        .border(1.dp, SubtleBorderViolet, RoundedCornerShape(10.dp))
                                        .clickable {
                                            viewModel.updateImageDraft {
                                                it.copy(seed = Random.nextLong(100_000L, 999_999L))
                                            }
                                        }
                                        .padding(horizontal = 10.dp, vertical = 8.dp)
                                ) {
                                    Text("${draft.seed}", style = MaterialTheme.typography.labelMedium, color = NeonCyan)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Icon(Icons.Rounded.Casino, contentDescription = "Nueva semilla", tint = NeonCyan, modifier = Modifier.size(16.dp))
                                }
                            }
                        }

                        Text("Estilo visual", style = MaterialTheme.typography.titleSmall, color = TextPrimary)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            styles.forEach { st ->
                                OptionChip(
                                    label = st,
                                    selected = draft.styleLook == st,
                                    onClick = { viewModel.updateImageDraft { it.copy(styleLook = st) } }
                                )
                            }
                        }
                    }
                }
            }

            item {
                GenerationStatusBanner(
                    progress = progress,
                    onDismiss = { viewModel.resetImageProgress() }
                )
            }

            item {
                LunaGradientButton(
                    text = if (isBusy) "Generando en la nube..." else "Generar imagen",
                    onClick = { viewModel.generateCloudImage(context) },
                    enabled = !isBusy,
                    icon = Icons.Rounded.AutoAwesome,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("generate_image_submit_button")
                )
            }

            // Latest Result Card
            if (draft.latestGeneratedPath.isNotBlank() && File(draft.latestGeneratedPath).exists()) {
                item {
                    LunaGlassCard(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text("Resultado generado", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                            Spacer(modifier = Modifier.height(10.dp))
                            AsyncImage(
                                model = File(draft.latestGeneratedPath),
                                contentDescription = "Imagen generada",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .aspectRatio(1f)
                                    .clip(RoundedCornerShape(16.dp))
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                LunaGradientButton(
                                    text = stringResource(R.string.download_action),
                                    onClick = {
                                        viewModel.downloadImageToDevice(
                                            context,
                                            draft.latestGeneratedPath,
                                            draft.prompt.take(30)
                                        )
                                    },
                                    icon = Icons.Rounded.Download,
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("download_generated_image_button")
                                )
                                OutlinedButton(
                                    onClick = {
                                        viewModel.sendImageToVideoStudio(draft.latestGeneratedPath, draft.prompt)
                                        onSendToVideoStudio()
                                    },
                                    shape = RoundedCornerShape(16.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(50.dp)
                                        .testTag("send_to_video_button")
                                ) {
                                    Icon(Icons.Rounded.MovieCreation, contentDescription = null, tint = ElectricViolet, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Animar", color = TextPrimary)
                                }
                            }
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(12.dp)) }
        }
    }
}

@Composable
private fun OptionChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (selected) NeonCyan.copy(alpha = 0.2f) else MidnightBg.copy(alpha = 0.7f))
            .border(
                1.dp,
                if (selected) NeonCyan else SubtleBorderViolet,
                RoundedCornerShape(10.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = if (selected) NeonCyan else TextSecondary
        )
    }
}

package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.CloudDone
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.credentials.CredentialManager
import coil.compose.AsyncImage
import com.example.R
import com.example.model.GeneratedMedia
import com.example.model.UiState
import com.example.model.VideoProject
import com.example.ui.auth.signOut
import com.example.ui.components.LunaGlassCard
import com.example.ui.components.LunaGradientButton
import com.example.ui.components.LunaLogo
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.EmeraldActive
import com.example.ui.theme.GlassCardElevated
import com.example.ui.theme.MagentaAccent
import com.example.ui.theme.MidnightBg
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.SubtleBorderViolet
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.LunaStudioViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import java.io.File

@Composable
fun GalleryScreen(
    generationsState: UiState<List<GeneratedMedia>>,
    projectsState: UiState<List<VideoProject>>,
    viewModel: LunaStudioViewModel,
    onOpenVideoProject: (VideoProject) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember { CredentialManager.create(context) }

    // Internal tabs: Buscar, Recientes, Favoritos, Perfil
    var selectedTab by remember { mutableIntStateOf(1) }
    var searchQuery by remember { mutableStateOf("") }
    var typeFilter by remember { mutableStateOf("all") }
    var previewMedia by remember { mutableStateOf<GeneratedMedia?>(null) }

    val tabs = listOf(
        0 to ("Buscar" to Icons.Rounded.Search),
        1 to ("Recientes" to Icons.Rounded.History),
        2 to ("Favoritos" to Icons.Rounded.Favorite),
        3 to ("Perfil" to Icons.Rounded.Person)
    )

    val allMedia = (generationsState as? UiState.Success)?.data.orEmpty()
    val allProjects = (projectsState as? UiState.Success)?.data.orEmpty()

    val filteredMedia = remember(allMedia, selectedTab, searchQuery, typeFilter) {
        val base = when (selectedTab) {
            2 -> allMedia.filter { it.favorite }
            else -> allMedia
        }
        val byType = if (typeFilter == "all") base else base.filter { it.mediaType == typeFilter }
        if (searchQuery.isBlank()) byType else {
            byType.filter {
                it.title.contains(searchQuery, ignoreCase = true) ||
                    it.prompt.contains(searchQuery, ignoreCase = true) ||
                    it.styleLook.contains(searchQuery, ignoreCase = true)
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MidnightBg),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 640.dp)
                .padding(horizontal = 18.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                LunaLogo(size = 36.dp)
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "Galería y Resultados",
                        style = MaterialTheme.typography.headlineMedium,
                        color = TextPrimary
                    )
                    Text(
                        text = "${allMedia.size} generaciones guardadas en la nube",
                        style = MaterialTheme.typography.labelSmall,
                        color = NeonCyan
                    )
                }
            }

            // Internal Navigation Tabs: Buscar, Recientes, Favoritos, Perfil
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(tabs) { (idx, pair) ->
                    val (label, icon) = pair
                    val active = selectedTab == idx
                    FilterChip(
                        selected = active,
                        onClick = { selectedTab = idx },
                        label = { Text(label) },
                        leadingIcon = {
                            Icon(
                                imageVector = icon,
                                contentDescription = label,
                                modifier = Modifier.size(16.dp)
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            containerColor = GlassCardElevated,
                            labelColor = TextSecondary,
                            iconColor = TextSecondary,
                            selectedContainerColor = NeonCyan.copy(alpha = 0.2f),
                            selectedLabelColor = NeonCyan,
                            selectedLeadingIconColor = NeonCyan
                        ),
                        modifier = Modifier.testTag("gallery_tab_$label")
                    )
                }
            }

            if (selectedTab == 3) {
                // Perfil Tab
                val currentUser = Firebase.auth.currentUser
                LunaGlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(56.dp)
                                    .clip(CircleShape)
                                    .background(
                                        Brush.linearGradient(listOf(NeonCyan, ElectricViolet))
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = (currentUser?.displayName?.firstOrNull()
                                        ?: currentUser?.email?.firstOrNull()
                                        ?: 'L').uppercase(),
                                    style = MaterialTheme.typography.headlineMedium,
                                    color = TextPrimary
                                )
                            }
                            Spacer(modifier = Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = currentUser?.displayName?.ifBlank { null } ?: "Creador Luna AI",
                                    style = MaterialTheme.typography.titleLarge,
                                    color = TextPrimary
                                )
                                Text(
                                    text = currentUser?.email ?: "Sesión de Google activa",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(MidnightBg.copy(alpha = 0.7f))
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Rounded.CloudDone, contentDescription = null, tint = EmeraldActive)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Sincronización Cloud Firestore Activa",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "Motor gratuito: Firebase AI Logic (Gemini 3.8 + Nano Banana 2.1)",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            StatBox(
                                value = "${allMedia.size}",
                                label = "Creaciones",
                                modifier = Modifier.weight(1f)
                            )
                            StatBox(
                                value = "${allMedia.count { it.favorite }}",
                                label = "Favoritos",
                                modifier = Modifier.weight(1f)
                            )
                            StatBox(
                                value = "${allProjects.size}",
                                label = "Videos",
                                modifier = Modifier.weight(1f)
                            )
                        }

                        OutlinedButton(
                            onClick = {
                                signOut(credentialManager = credentialManager, scope = scope)
                            },
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("sign_out_button")
                        ) {
                            Icon(Icons.AutoMirrored.Rounded.Logout, contentDescription = null, tint = MagentaAccent)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Cerrar sesión", color = MagentaAccent)
                        }
                    }
                }
            } else {
                // Buscar / Recientes / Favoritos Grid
                if (selectedTab == 0) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Buscar por prompt, estilo o título...", color = TextMuted) },
                        leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null, tint = NeonCyan) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonCyan,
                            unfocusedBorderColor = SubtleBorderViolet,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("gallery_search_input")
                    )

                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        val filters = listOf(
                            "all" to "Todos",
                            "image" to "Imágenes",
                            "video" to "Videos",
                            "character" to "Personajes"
                        )
                        items(filters) { (key, label) ->
                            FilterChip(
                                selected = typeFilter == key,
                                onClick = { typeFilter = key },
                                label = { Text(label) },
                                colors = FilterChipDefaults.filterChipColors(
                                    containerColor = MidnightBg,
                                    labelColor = TextSecondary,
                                    selectedContainerColor = ElectricViolet.copy(alpha = 0.25f),
                                    selectedLabelColor = TextPrimary
                                )
                            )
                        }
                    }
                }

                when (generationsState) {
                    is UiState.Loading -> {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(color = NeonCyan)
                        }
                    }
                    is UiState.Error -> {
                        LunaGlassCard(modifier = Modifier.fillMaxWidth()) {
                            Text(
                                text = generationsState.message,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MagentaAccent,
                                modifier = Modifier.padding(16.dp)
                            )
                        }
                    }
                    is UiState.Success -> {
                        if (filteredMedia.isEmpty()) {
                            LunaGlassCard(modifier = Modifier.fillMaxWidth()) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(28.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.AutoAwesome,
                                        contentDescription = null,
                                        tint = NeonCyan,
                                        modifier = Modifier.size(36.dp)
                                    )
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text(
                                        text = if (selectedTab == 2) "Aún no tienes favoritos" else "Tu galería está lista para crear",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = TextPrimary
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "Genera imágenes, videos o personajes IA y aparecerán aquí al instante.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSecondary
                                    )
                                }
                            }
                        } else {
                            LazyVerticalGrid(
                                columns = GridCells.Adaptive(minSize = 156.dp),
                                contentPadding = PaddingValues(bottom = 16.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier.fillMaxSize()
                            ) {
                                items(filteredMedia, key = { it.id }) { media ->
                                    GalleryMediaCard(
                                        media = media,
                                        onTap = {
                                            if (media.mediaType == "video" && media.projectId.isNotBlank()) {
                                                val proj = allProjects.firstOrNull { it.id == media.projectId }
                                                if (proj != null) {
                                                    onOpenVideoProject(proj)
                                                } else {
                                                    previewMedia = media
                                                }
                                            } else {
                                                previewMedia = media
                                            }
                                        },
                                        onToggleFavorite = { viewModel.toggleFavorite(media) },
                                        onDownload = {
                                            if (media.mediaType == "video" && media.projectId.isNotBlank()) {
                                                val proj = allProjects.firstOrNull { it.id == media.projectId }
                                                if (proj != null) {
                                                    viewModel.downloadVideoToDevice(context, proj)
                                                } else {
                                                    viewModel.downloadImageToDevice(context, media.localFilePath, media.title)
                                                }
                                            } else {
                                                viewModel.downloadImageToDevice(context, media.localFilePath, media.title)
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (previewMedia != null) {
        val media = previewMedia!!
        Dialog(onDismissRequest = { previewMedia = null }) {
            LunaGlassCard(
                modifier = Modifier.fillMaxWidth(),
                containerColor = ObsidianSurface,
                cornerRadius = 22.dp
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = media.title,
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = { previewMedia = null }) {
                            Icon(Icons.Rounded.Close, contentDescription = "Cerrar", tint = TextSecondary)
                        }
                    }
                    if (media.localFilePath.isNotBlank() && File(media.localFilePath).exists()) {
                        AsyncImage(
                            model = File(media.localFilePath),
                            contentDescription = media.title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(1f)
                                .clip(RoundedCornerShape(14.dp))
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = media.prompt,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        maxLines = 4
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        LunaGradientButton(
                            text = stringResource(R.string.download_action),
                            onClick = {
                                viewModel.downloadImageToDevice(context, media.localFilePath, media.title)
                            },
                            icon = Icons.Rounded.Download,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = {
                                viewModel.deleteMedia(media)
                                previewMedia = null
                            },
                            modifier = Modifier
                                .size(50.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(MidnightBg)
                                .border(1.dp, MagentaAccent.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                        ) {
                            Icon(Icons.Rounded.DeleteOutline, contentDescription = "Eliminar", tint = MagentaAccent)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GalleryMediaCard(
    media: GeneratedMedia,
    onTap: () -> Unit,
    onToggleFavorite: () -> Unit,
    onDownload: () -> Unit
) {
    LunaGlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onTap),
        cornerRadius = 18.dp
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .background(ObsidianSurface)
        ) {
            if (media.localFilePath.isNotBlank() && File(media.localFilePath).exists()) {
                AsyncImage(
                    model = File(media.localFilePath),
                    contentDescription = media.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                MidnightBg.copy(alpha = 0.35f),
                                Color.Transparent,
                                MidnightBg.copy(alpha = 0.85f)
                            )
                        )
                    )
            )

            // Type pill
            Box(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(8.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(MidnightBg.copy(alpha = 0.72f))
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
                Text(
                    text = when (media.mediaType) {
                        "video" -> "VIDEO"
                        "character" -> "PERSONAJE"
                        else -> media.aspectRatio
                    },
                    style = MaterialTheme.typography.labelSmall,
                    color = NeonCyan
                )
            }

            // Favorite heart
            IconButton(
                onClick = onToggleFavorite,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(2.dp)
            ) {
                Icon(
                    imageVector = if (media.favorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                    contentDescription = "Favorito",
                    tint = if (media.favorite) MagentaAccent else TextPrimary
                )
            }

            if (media.mediaType == "video") {
                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(MidnightBg.copy(alpha = 0.7f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Rounded.PlayArrow, contentDescription = "Reproducir", tint = NeonCyan)
                }
            }

            Text(
                text = media.title,
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                color = TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(horizontal = 10.dp, vertical = 8.dp)
            )
        }

        Button(
            onClick = onDownload,
            colors = ButtonDefaults.buttonColors(
                containerColor = GlassCardElevated,
                contentColor = NeonCyan
            ),
            shape = RoundedCornerShape(0.dp),
            contentPadding = PaddingValues(vertical = 8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(42.dp)
                .testTag("gallery_download_${media.id}")
        ) {
            Icon(Icons.Rounded.Download, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(stringResource(R.string.download_action), style = MaterialTheme.typography.labelLarge)
        }
    }
}

@Composable
private fun StatBox(
    value: String,
    label: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(MidnightBg.copy(alpha = 0.7f))
            .padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(value, style = MaterialTheme.typography.headlineSmall, color = NeonCyan)
        Text(label, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
    }
}

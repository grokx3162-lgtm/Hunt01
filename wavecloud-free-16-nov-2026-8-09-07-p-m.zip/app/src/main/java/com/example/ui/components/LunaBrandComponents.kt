package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MovieCreation
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Collections
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MovieCreation
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.model.GenerationProgress
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.EmeraldActive
import com.example.ui.theme.GlassCardBg
import com.example.ui.theme.GlassCardElevated
import com.example.ui.theme.MagentaAccent
import com.example.ui.theme.MidnightBg
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.SubtleBorderCyan
import com.example.ui.theme.SubtleBorderViolet
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

/**
 * Custom crescent moon + 4-point sparkle star brand mark for Luna AI.
 */
@Composable
fun LunaLogo(
    size: Dp = 36.dp,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(size * 0.28f))
            .background(
                Brush.linearGradient(
                    colors = listOf(GlassCardElevated, MidnightBg)
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(listOf(NeonCyan.copy(alpha = 0.65f), ElectricViolet.copy(alpha = 0.65f))),
                shape = RoundedCornerShape(size * 0.28f)
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size * 0.68f)) {
            val w = this.size.width
            val h = this.size.height
            val moonBrush = Brush.linearGradient(
                colors = listOf(NeonCyan, ElectricViolet),
                start = Offset(0f, 0f),
                end = Offset(w, h)
            )
            // Crescent moon using Path
            val moonPath = Path().apply {
                moveTo(w * 0.56f, h * 0.12f)
                cubicTo(
                    w * 0.18f, h * 0.14f,
                    w * 0.08f, h * 0.54f,
                    w * 0.28f, h * 0.78f
                )
                cubicTo(
                    w * 0.44f, h * 0.96f,
                    w * 0.74f, h * 0.90f,
                    w * 0.86f, h * 0.70f
                )
                cubicTo(
                    w * 0.64f, h * 0.78f,
                    w * 0.42f, h * 0.64f,
                    w * 0.40f, h * 0.44f
                )
                cubicTo(
                    w * 0.39f, h * 0.28f,
                    w * 0.47f, h * 0.18f,
                    w * 0.56f, h * 0.12f
                )
                close()
            }
            drawPath(path = moonPath, brush = moonBrush, style = Fill)

            // 4-point sparkle star in upper-right quadrant
            val cx = w * 0.72f
            val cy = h * 0.28f
            val r = w * 0.18f
            val starPath = Path().apply {
                moveTo(cx, cy - r)
                quadraticTo(cx, cy, cx + r, cy)
                quadraticTo(cx, cy, cx, cy + r)
                quadraticTo(cx, cy, cx - r, cy)
                quadraticTo(cx, cy, cx, cy - r)
                close()
            }
            drawPath(path = starPath, color = Color.White, style = Fill)
        }
    }
}

@Composable
fun LunaGlassCard(
    modifier: Modifier = Modifier,
    borderBrush: Brush = Brush.linearGradient(listOf(SubtleBorderCyan, SubtleBorderViolet)),
    containerColor: Color = GlassCardBg,
    cornerRadius: Dp = 20.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(cornerRadius))
            .background(containerColor)
            .border(1.dp, borderBrush, RoundedCornerShape(cornerRadius)),
        content = content
    )
}

@Composable
fun LunaGradientButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    icon: ImageVector? = null,
    gradientColors: List<Color> = listOf(NeonCyan, ElectricViolet)
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 14.dp),
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = Color.Transparent,
            disabledContainerColor = Color.Transparent,
            contentColor = TextPrimary,
            disabledContentColor = TextSecondary
        ),
        modifier = modifier
            .heightIn(min = 50.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(
                if (enabled) Brush.horizontalGradient(gradientColors)
                else Brush.horizontalGradient(listOf(GlassCardElevated, GlassCardElevated))
            )
    ) {
        if (icon != null) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = TextPrimary,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
        }
        Text(
            text = text,
            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
            color = TextPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun LunaCollapsibleSection(
    title: String,
    subtitle: String? = null,
    icon: ImageVector,
    expanded: Boolean,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = "",
    content: @Composable ColumnScope.() -> Unit
) {
    LunaGlassCard(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .then(if (testTag.isNotBlank()) Modifier.testTag(testTag) else Modifier)
                .clickable(onClick = onToggle)
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(MidnightBg.copy(alpha = 0.7f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = NeonCyan,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary
                )
                if (!subtitle.isNullOrBlank()) {
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            Icon(
                imageVector = if (expanded) Icons.Rounded.KeyboardArrowUp else Icons.Rounded.KeyboardArrowDown,
                contentDescription = if (expanded) "Colapsar" else "Expandir",
                tint = TextSecondary
            )
        }
        AnimatedVisibility(
            visible = expanded,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 16.dp, end = 16.dp, bottom = 16.dp),
                content = content
            )
        }
    }
}

@Composable
fun GenerationStatusBanner(
    progress: GenerationProgress,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    when (progress) {
        is GenerationProgress.Idle -> Unit
        is GenerationProgress.Working -> {
            LunaGlassCard(
                modifier = modifier.fillMaxWidth(),
                borderBrush = Brush.linearGradient(listOf(NeonCyan, ElectricViolet))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = progress.stage,
                            style = MaterialTheme.typography.titleSmall,
                            color = TextPrimary,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "${(progress.progress * 100).toInt()}%",
                            style = MaterialTheme.typography.labelMedium,
                            color = NeonCyan
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    LinearProgressIndicator(
                        progress = { progress.progress.coerceIn(0f, 1f) },
                        color = NeonCyan,
                        trackColor = MidnightBg,
                        strokeCap = StrokeCap.Round,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                    )
                }
            }
        }
        is GenerationProgress.Completed -> {
            LunaGlassCard(
                modifier = modifier
                    .fillMaxWidth()
                    .clickable(onClick = onDismiss),
                borderBrush = Brush.linearGradient(listOf(EmeraldActive, NeonCyan))
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(EmeraldActive)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = progress.message,
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextPrimary,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
        is GenerationProgress.Error -> {
            LunaGlassCard(
                modifier = modifier
                    .fillMaxWidth()
                    .clickable(onClick = onDismiss),
                borderBrush = Brush.linearGradient(listOf(MagentaAccent, ElectricViolet))
            ) {
                Text(
                    text = progress.message,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MagentaAccent,
                    modifier = Modifier.padding(14.dp)
                )
            }
        }
    }
}

data class LunaNavTab(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)

val LUNA_BOTTOM_TABS = listOf(
    LunaNavTab("home", "Inicio", Icons.Filled.Home, Icons.Outlined.Home),
    LunaNavTab("video_studio", "Video", Icons.Filled.MovieCreation, Icons.Outlined.MovieCreation),
    LunaNavTab("image_studio", "Imágenes", Icons.Filled.AutoAwesome, Icons.Outlined.AutoAwesome),
    LunaNavTab("characters", "Personajes", Icons.Filled.Person, Icons.Outlined.Person),
    LunaNavTab("gallery", "Galería", Icons.Filled.Collections, Icons.Outlined.Collections)
)

@Composable
fun LunaBottomBar(
    currentRoute: String,
    onNavigate: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(Color(0xF20D1322))
            .border(
                width = 1.dp,
                color = Color(0x2638BDF8)
            )
            .navigationBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            LUNA_BOTTOM_TABS.forEach { tab ->
                val selected = currentRoute == tab.route
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 48.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .clickable { onNavigate(tab.route) }
                        .padding(vertical = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (selected) Brush.horizontalGradient(
                                    listOf(NeonCyan.copy(alpha = 0.22f), ElectricViolet.copy(alpha = 0.22f))
                                ) else Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent))
                            )
                            .padding(horizontal = 12.dp, vertical = 4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                            contentDescription = tab.label,
                            tint = if (selected) NeonCyan else TextSecondary,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = tab.label,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                        ),
                        color = if (selected) TextPrimary else TextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

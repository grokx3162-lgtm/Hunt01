package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val MidnightBg = Color(0xFF0B0F19)
val ObsidianSurface = Color(0xFF111726)
val GlassCardBg = Color(0xCC151D30)
val GlassCardElevated = Color(0xE61C2740)

val NeonCyan = Color(0xFF38BDF8)
val ElectricViolet = Color(0xFF8B5CF6)
val DeepIndigo = Color(0xFF4F46E5)
val MagentaAccent = Color(0xFFF43F5E)
val EmeraldActive = Color(0xFF10B981)
val AmberWarm = Color(0xFFF59E0B)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val SubtleBorderCyan = Color(0x4D38BDF8)
val SubtleBorderViolet = Color(0x4D8B5CF6)
val SurfaceDivider = Color(0x1FFFFFFF)

package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.VolumeOff
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.R
import com.example.core.VoicePreviewPlayer
import com.example.model.VideoProject
import com.example.ui.components.LunaGlassCard
import com.example.ui.components.LunaGradientButton
import com.example.ui.theme.AmberWarm
import com.example.ui.theme.MidnightBg
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.SubtleBorderViolet
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.LunaStudioViewModel
import kotlinx.coroutines.delay
import java.io.File
import kotlin.random.Random

@Composable
fun VideoPlayerScreen(
    project: VideoProject?,
    viewModel: LunaStudioViewModel,
    onBack: () -> Unit,
    onEditProject: (VideoProject) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val activeProject = project ?: VideoProject()
    val keyframes = activeProject.keyframePaths.filter { it.isNotBlank() && File(it).exists() }
    val totalDurationSec = activeProject.durationSec.toInt().coerceIn(5, 30)

    var isPlaying by remember { mutableStateOf(true) }
    var isMuted by remember { mutableStateOf(false) }
    var isFullscreen by remember { mutableStateOf(false) }
    var elapsedSec by remember { mutableFloatStateOf(0f) }

    val voicePlayer = remember { VoicePreviewPlayer(context) }
    DisposableEffect(Unit) {
        onDispose { voicePlayer.release() }
    }

    // Smooth playback loop across keyframes with Ken Burns interpolation
    LaunchedEffect(isPlaying, totalDurationSec, keyframes.size) {
        if (!isPlaying || keyframes.isEmpty()) return@LaunchedEffect
        if (!isMuted && elapsedSec < 0.5f && activeProject.voiceoverScript.isNotBlank()) {
            voicePlayer.speak(
                activeProject.voiceoverScript,
                activeProject.voiceName,
                activeProject.voicePace
            )
        }
        while (isPlaying) {
            delay(50L)
            elapsedSec += 0.05f
            if (elapsedSec >= totalDurationSec.toFloat()) {
                elapsedSec = 0f
                if (!isMuted && activeProject.voiceoverScript.isNotBlank()) {
                    voicePlayer.speak(
                        activeProject.voiceoverScript,
                        activeProject.voiceName,
                        activeProject.voicePace
                    )
                }
            }
        }
    }

    val currentFrameIndex = if (keyframes.isEmpty()) 0 else {
        ((elapsedSec / totalDurationSec.toFloat()) * keyframes.size)
            .toInt()
            .coerceIn(0, keyframes.lastIndex)
    }

    val frameProgress = if (keyframes.isEmpty()) 0f else {
        val segmentDur = totalDurationSec.toFloat() / keyframes.size.toFloat()
        ((elapsedSec % segmentDur) / segmentDur).coerceIn(0f, 1f)
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MidnightBg),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 640.dp)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Top Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        voicePlayer.stop()
                        onBack()
                    },
                    modifier = Modifier.testTag("player_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                        contentDescription = "Volver",
                        tint = TextPrimary
                    )
                }
                Spacer(modifier = Modifier.width(6.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = activeProject.title.ifBlank { "Resultado de Video" },
                        style = MaterialTheme.typography.titleLarge,
                        color = TextPrimary
                    )
                    Text(
                        text = "${activeProject.cameraModel} • ${activeProject.lens} • ${activeProject.lookStyle}",
                        style = MaterialTheme.typography.labelSmall,
                        color = NeonCyan
                    )
                }
            }

            // Video Player Viewport
            LunaGlassCard(
                modifier = Modifier.fillMaxWidth(),
                cornerRadius = 22.dp
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(9f / 12f)
                        .background(MidnightBg)
                ) {
                    VideoFrameRenderer(
                        framePath = keyframes.getOrNull(currentFrameIndex),
                        kenBurnsProgress = frameProgress,
                        warmLightPct = activeProject.warmLightPct.toInt(),
                        grainPct = activeProject.grainPct.toInt(),
                        modifier = Modifier.fillMaxSize()
                    )

                    // Overlay Top Badges (Timecode + Volume + Fullscreen)
                    Row(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(MidnightBg.copy(alpha = 0.72f))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "${formatTime(elapsedSec.toInt())} / ${formatTime(totalDurationSec)}",
                                style = MaterialTheme.typography.labelMedium,
                                color = NeonCyan
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            IconButton(
                                onClick = {
                                    isMuted = !isMuted
                                    if (isMuted) voicePlayer.stop()
                                },
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(MidnightBg.copy(alpha = 0.72f))
                                    .testTag("player_mute_button")
                            ) {
                                Icon(
                                    imageVector = if (isMuted) Icons.AutoMirrored.Rounded.VolumeOff else Icons.AutoMirrored.Rounded.VolumeUp,
                                    contentDescription = if (isMuted) "Activar sonido" else "Silenciar",
                                    tint = TextPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            IconButton(
                                onClick = { isFullscreen = true },
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(MidnightBg.copy(alpha = 0.72f))
                                    .testTag("player_fullscreen_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Fullscreen,
                                    contentDescription = "Pantalla completa",
                                    tint = TextPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }

                    // Center Play/Pause Tap Control
                    IconButton(
                        onClick = {
                            isPlaying = !isPlaying
                            if (!isPlaying) voicePlayer.stop()
                        },
                        modifier = Modifier
                            .align(Alignment.Center)
                            .size(58.dp)
                            .clip(CircleShape)
                            .background(MidnightBg.copy(alpha = 0.6f))
                            .border(1.dp, NeonCyan.copy(alpha = 0.6f), CircleShape)
                            .testTag("player_play_pause_button")
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                            contentDescription = if (isPlaying) "Pausar" else "Reproducir",
                            tint = TextPrimary,
                            modifier = Modifier.size(30.dp)
                        )
                    }

                    // Bottom Scrubber Timeline Bar
                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .background(MidnightBg.copy(alpha = 0.78f))
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Slider(
                            value = elapsedSec,
                            onValueChange = { newTime ->
                                elapsedSec = newTime
                            },
                            valueRange = 0f..totalDurationSec.toFloat(),
                            colors = SliderDefaults.colors(
                                thumbColor = NeonCyan,
                                activeTrackColor = NeonCyan,
                                inactiveTrackColor = TextSecondary.copy(alpha = 0.35f)
                            ),
                            modifier = Modifier.testTag("player_timeline_slider")
                        )
                    }
                }
            }

            // Bottom Keyframe Scrub Carousel
            if (keyframes.isNotEmpty()) {
                LunaGlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "Fotogramas clave (${keyframes.size})",
                            style = MaterialTheme.typography.titleSmall,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            itemsIndexed(keyframes) { idx, path ->
                                val selected = idx == currentFrameIndex
                                val frameStartSec = ((idx.toFloat() / keyframes.size) * totalDurationSec).toInt()
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier
                                        .width(78.dp)
                                        .clickable {
                                            elapsedSec = frameStartSec.toFloat()
                                        }
                                        .testTag("keyframe_thumb_$idx")
                                ) {
                                    AsyncImage(
                                        model = File(path),
                                        contentDescription = "Fotograma ${idx + 1}",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .aspectRatio(9f / 12f)
                                            .clip(RoundedCornerShape(10.dp))
                                            .border(
                                                width = if (selected) 2.dp else 1.dp,
                                                color = if (selected) NeonCyan else SubtleBorderViolet,
                                                shape = RoundedCornerShape(10.dp)
                                            )
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = formatTime(frameStartSec),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (selected) NeonCyan else TextSecondary
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Action Buttons: Descargar & Editar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                LunaGradientButton(
                    text = stringResource(R.string.download_action),
                    onClick = { viewModel.downloadVideoToDevice(context, activeProject) },
                    icon = Icons.Rounded.Download,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("download_video_button")
                )

                OutlinedButton(
                    onClick = {
                        voicePlayer.stop()
                        onEditProject(activeProject)
                    },
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("edit_video_button")
                ) {
                    Icon(Icons.Rounded.Edit, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(stringResource(R.string.edit_action), color = TextPrimary)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
        }
    }

    if (isFullscreen) {
        Dialog(
            onDismissRequest = { isFullscreen = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MidnightBg)
            ) {
                VideoFrameRenderer(
                    framePath = keyframes.getOrNull(currentFrameIndex),
                    kenBurnsProgress = frameProgress,
                    warmLightPct = activeProject.warmLightPct.toInt(),
                    grainPct = activeProject.grainPct.toInt(),
                    modifier = Modifier.fillMaxSize()
                )
                IconButton(
                    onClick = { isFullscreen = false },
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(20.dp)
                        .clip(CircleShape)
                        .background(MidnightBg.copy(alpha = 0.75f))
                ) {
                    Icon(Icons.Rounded.Close, contentDescription = "Cerrar pantalla completa", tint = TextPrimary)
                }
            }
        }
    }
}

@Composable
private fun VideoFrameRenderer(
    framePath: String?,
    kenBurnsProgress: Float,
    warmLightPct: Int,
    grainPct: Int,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier) {
        if (!framePath.isNullOrBlank()) {
            AsyncImage(
                model = File(framePath),
                contentDescription = "Fotograma de video",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        val s = 1f + (0.07f * kenBurnsProgress)
                        scaleX = s
                        scaleY = s
                    }
            )
        } else {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MidnightBg),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Genera un video en la pestaña Video para reproducirlo aquí",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
            }
        }

        // Warm light tint overlay matching Ajustes de toma
        if (warmLightPct > 0) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(AmberWarm.copy(alpha = (warmLightPct / 100f) * 0.18f))
            )
        }

        // Subtle film grain overlay
        if (grainPct > 0) {
            val grainSeed = remember(kenBurnsProgress) { (kenBurnsProgress * 100).toInt() }
            Canvas(modifier = Modifier.fillMaxSize()) {
                val rng = Random(grainSeed)
                val dotCount = (grainPct * 2).coerceAtMost(180)
                val dotAlpha = (grainPct / 100f) * 0.16f
                repeat(dotCount) {
                    val x = rng.nextFloat() * size.width
                    val y = rng.nextFloat() * size.height
                    drawCircle(
                        color = Color.White.copy(alpha = dotAlpha),
                        radius = 1.4f,
                        center = Offset(x, y)
                    )
                }
            }
        }
    }
}

private fun formatTime(seconds: Int): String {
    val m = seconds / 60
    val s = seconds % 60
    return "%d:%02d".format(m, s)
}

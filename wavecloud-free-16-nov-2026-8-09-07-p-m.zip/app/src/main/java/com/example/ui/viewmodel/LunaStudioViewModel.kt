package com.example.ui.viewmodel

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.R
import com.example.core.MediaStorageHelper
import com.example.data.LunaAiRepository
import com.example.data.LunaFirestoreRepository
import com.example.model.GeneratedMedia
import com.example.model.GenerationProgress
import com.example.model.LunaCharacter
import com.example.model.UiState
import com.example.model.VideoProject
import com.google.firebase.ai.type.QuotaExceededException
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.coroutines.cancellation.CancellationException
import kotlin.random.Random

private const val TAG = "LunaStudioVM"

data class ImageStudioDraft(
    val prompt: String = "",
    val modelId: String = "gemini-nano-banana-2.1",
    val aspectRatio: String = "1:1",
    val resolution: String = "1K",
    val styleLook: String = "Profesional",
    val seed: Long = 482910L,
    val referenceImagePath: String = "",
    val latestGeneratedPath: String = "",
    val latestGenerationId: String = ""
)

data class VideoStudioDraft(
    val editingProjectId: String = "",
    val title: String = "Escena Luna AI",
    val topic: String = "",
    val cameraPrompt: String = "",
    val voiceoverScript: String = "",
    val durationSec: Int = 15,
    val lookStyle: String = "Profesional",
    val cameraModel: String = "ARRI Alexa 35",
    val lens: String = "50 mm",
    val warmLightPct: Int = 35,
    val grainPct: Int = 18,
    val voiceName: String = "Luna Clara",
    val voicePace: String = "Natural",
    val referenceImagePath: String = "",
    val keyframePrompts: List<String> = emptyList()
)

data class CharacterStudioDraft(
    val editingId: String = "",
    val codeName: String = "Luna-001",
    val seed: Long = 849201L,
    val description: String = "Musa digital editorial con cabello plateado-violeta luminiscente, iluminación neón cian sutil y estética cinematográfica 50mm.",
    val stylePreset: String = "Profesional",
    val selectedVariation: Int = 0,
    val primaryImagePath: String = "",
    val variationPaths: List<String> = emptyList()
)

class LunaStudioViewModel(
    private val firestoreRepo: LunaFirestoreRepository,
    private val aiRepo: LunaAiRepository,
    private val currentUserId: String
) : ViewModel() {

    val charactersState: StateFlow<UiState<List<LunaCharacter>>> =
        firestoreRepo.observeCharacters(currentUserId)
            .map<List<LunaCharacter>, UiState<List<LunaCharacter>>> { UiState.Success(it) }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val rootError = firestoreError ?: error
                Log.w(TAG, "Error observing characters", rootError)
                emit(UiState.Error(rootError.localizedMessage ?: "Error al sincronizar personajes."))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = UiState.Loading
            )

    val projectsState: StateFlow<UiState<List<VideoProject>>> =
        firestoreRepo.observeProjects(currentUserId)
            .map<List<VideoProject>, UiState<List<VideoProject>>> { UiState.Success(it) }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val rootError = firestoreError ?: error
                Log.w(TAG, "Error observing projects", rootError)
                emit(UiState.Error(rootError.localizedMessage ?: "Error al sincronizar proyectos."))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = UiState.Loading
            )

    val generationsState: StateFlow<UiState<List<GeneratedMedia>>> =
        firestoreRepo.observeGenerations(currentUserId)
            .map<List<GeneratedMedia>, UiState<List<GeneratedMedia>>> { UiState.Success(it) }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val rootError = firestoreError ?: error
                Log.w(TAG, "Error observing generations", rootError)
                emit(UiState.Error(rootError.localizedMessage ?: "Error al sincronizar galería."))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = UiState.Loading
            )

    private val _imageDraft = MutableStateFlow(ImageStudioDraft())
    val imageDraft: StateFlow<ImageStudioDraft> = _imageDraft.asStateFlow()

    private val _videoDraft = MutableStateFlow(VideoStudioDraft())
    val videoDraft: StateFlow<VideoStudioDraft> = _videoDraft.asStateFlow()

    private val _characterDraft = MutableStateFlow(CharacterStudioDraft())
    val characterDraft: StateFlow<CharacterStudioDraft> = _characterDraft.asStateFlow()

    private val _imageProgress = MutableStateFlow<GenerationProgress>(GenerationProgress.Idle)
    val imageProgress: StateFlow<GenerationProgress> = _imageProgress.asStateFlow()

    private val _videoProgress = MutableStateFlow<GenerationProgress>(GenerationProgress.Idle)
    val videoProgress: StateFlow<GenerationProgress> = _videoProgress.asStateFlow()

    private val _characterProgress = MutableStateFlow<GenerationProgress>(GenerationProgress.Idle)
    val characterProgress: StateFlow<GenerationProgress> = _characterProgress.asStateFlow()

    private val _uploadProgress = MutableStateFlow<Float?>(null)
    val uploadProgress: StateFlow<Float?> = _uploadProgress.asStateFlow()

    private val _activeVideoProject = MutableStateFlow<VideoProject?>(null)
    val activeVideoProject: StateFlow<VideoProject?> = _activeVideoProject.asStateFlow()

    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    private var starterInitialized = false

    fun initializeStarterAssets(context: Context) {
        if (starterInitialized) return
        starterInitialized = true
        viewModelScope.launch {
            try {
                val charPath = MediaStorageHelper.ensureDrawableCached(
                    context,
                    R.drawable.img_luna_character,
                    "luna_001_base.jpg"
                )
                firestoreRepo.seedDefaultCharacterIfEmpty(currentUserId, charPath)
                if (_characterDraft.value.primaryImagePath.isBlank()) {
                    _characterDraft.update {
                        it.copy(
                            primaryImagePath = charPath,
                            variationPaths = listOf(charPath)
                        )
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.w(TAG, "Starter seed skipped: ${e.message}")
            }
        }
    }

    fun consumeSnackbar() {
        _snackbarMessage.value = null
    }

    fun showMessage(message: String) {
        _snackbarMessage.value = message
    }

    fun resetImageProgress() {
        _imageProgress.value = GenerationProgress.Idle
    }

    fun resetVideoProgress() {
        _videoProgress.value = GenerationProgress.Idle
    }

    fun resetCharacterProgress() {
        _characterProgress.value = GenerationProgress.Idle
    }

    // --- Image Studio Draft Updates ---
    fun updateImageDraft(transform: (ImageStudioDraft) -> ImageStudioDraft) {
        _imageDraft.update(transform)
    }

    fun pickImageReference(context: Context, uri: Uri) {
        viewModelScope.launch {
            _uploadProgress.value = 0.35f
            try {
                val (path, _) = MediaStorageHelper.copyPickedUriToInternal(context, uri, "img_ref")
                _uploadProgress.value = 1.0f
                _imageDraft.update { it.copy(referenceImagePath = path) }
                _snackbarMessage.value = "Imagen de referencia cargada."
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _snackbarMessage.value = "No se pudo cargar la imagen: ${e.localizedMessage}"
            } finally {
                _uploadProgress.value = null
            }
        }
    }

    fun enhanceImagePrompt() {
        val current = _imageDraft.value.prompt.trim()
        if (current.isBlank()) {
            _snackbarMessage.value = "Escribe una idea breve primero para mejorarla con IA."
            return
        }
        viewModelScope.launch {
            _imageProgress.value = GenerationProgress.Working("Optimizando prompt con Gemini...", 0.3f)
            try {
                val enhanced = aiRepo.enhanceImagePrompt(current, _imageDraft.value.styleLook)
                _imageDraft.update { it.copy(prompt = enhanced) }
                _imageProgress.value = GenerationProgress.Idle
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _imageProgress.value = GenerationProgress.Error(mapAiError(e))
            }
        }
    }

    fun generateCloudImage(context: Context) {
        val draft = _imageDraft.value
        if (draft.prompt.isBlank()) {
            _imageProgress.value = GenerationProgress.Error("Ingresa un prompt descriptivo para generar.")
            return
        }
        viewModelScope.launch {
            _imageProgress.value = GenerationProgress.Working("Conectando con Firebase AI Logic...", 0.25f)
            try {
                val refBitmap = if (draft.referenceImagePath.isNotBlank()) {
                    MediaStorageHelper.loadBitmapFromPath(draft.referenceImagePath)
                } else null

                _imageProgress.value = GenerationProgress.Working(
                    "Sintetizando imagen (${draft.resolution} • ${draft.aspectRatio})...",
                    0.65f
                )
                val bitmap = aiRepo.generateImage(
                    prompt = draft.prompt,
                    modelId = draft.modelId,
                    aspectRatio = draft.aspectRatio,
                    resolution = draft.resolution,
                    styleLook = draft.styleLook,
                    referenceBitmap = refBitmap
                )

                _imageProgress.value = GenerationProgress.Working("Guardando en tu galería en la nube...", 0.9f)
                val savedPath = MediaStorageHelper.saveBitmapToInternal(context, bitmap, "gen_img")
                val title = draft.prompt.trim().take(42).ifBlank { "Imagen Luna AI" }
                val media = GeneratedMedia(
                    userId = currentUserId,
                    title = title,
                    prompt = draft.prompt,
                    mediaType = "image",
                    modelUsed = draft.modelId,
                    aspectRatio = draft.aspectRatio,
                    styleLook = draft.styleLook,
                    seed = draft.seed,
                    favorite = false,
                    localFilePath = savedPath,
                    projectId = ""
                )
                val result = firestoreRepo.saveGeneratedMedia(currentUserId, media)
                val docId = result.getOrNull().orEmpty()
                _imageDraft.update {
                    it.copy(
                        latestGeneratedPath = savedPath,
                        latestGenerationId = docId
                    )
                }
                _imageProgress.value = GenerationProgress.Completed("Imagen generada y sincronizada gratis en la nube.")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Image generation error", e)
                _imageProgress.value = GenerationProgress.Error(mapAiError(e))
            }
        }
    }

    // --- Video Studio Draft Updates ---
    fun updateVideoDraft(transform: (VideoStudioDraft) -> VideoStudioDraft) {
        _videoDraft.update(transform)
    }

    fun inspireVideoTopic() {
        viewModelScope.launch {
            _videoProgress.value = GenerationProgress.Working("Generando idea creativa...", 0.35f)
            try {
                val idea = aiRepo.generateInspirationTopic()
                _videoDraft.update { it.copy(topic = idea.take(300)) }
                _videoProgress.value = GenerationProgress.Idle
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _videoProgress.value = GenerationProgress.Error(mapAiError(e))
            }
        }
    }

    fun assembleVideoDirection() {
        val draft = _videoDraft.value
        if (draft.topic.isBlank()) {
            _videoProgress.value = GenerationProgress.Error("Escribe primero el Tema o Explicación.")
            return
        }
        viewModelScope.launch {
            _videoProgress.value = GenerationProgress.Working("Armando dirección de cámara y voz en off...", 0.45f)
            try {
                val direction = aiRepo.assembleVideoDirection(
                    topic = draft.topic,
                    lookStyle = draft.lookStyle,
                    cameraModel = draft.cameraModel,
                    lens = draft.lens,
                    durationSec = draft.durationSec
                )
                _videoDraft.update {
                    it.copy(
                        title = direction.title,
                        cameraPrompt = direction.cameraPrompt,
                        voiceoverScript = direction.voiceoverScript,
                        keyframePrompts = direction.keyframePrompts
                    )
                }
                _videoProgress.value = GenerationProgress.Completed("Dirección armada: cámara, voz en off y 4 fotogramas listos.")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Direction error", e)
                _videoProgress.value = GenerationProgress.Error(mapAiError(e))
            }
        }
    }

    fun pickVideoReference(context: Context, uri: Uri) {
        viewModelScope.launch {
            _uploadProgress.value = 0.4f
            try {
                val (path, _) = MediaStorageHelper.copyPickedUriToInternal(context, uri, "vid_ref")
                _uploadProgress.value = 1.0f
                _videoDraft.update { it.copy(referenceImagePath = path) }
                _snackbarMessage.value = "Foto de referencia lista para guiar el video."
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _snackbarMessage.value = "Error al cargar foto: ${e.localizedMessage}"
            } finally {
                _uploadProgress.value = null
            }
        }
    }

    fun createCloudVideo(
        context: Context,
        onVideoReady: (VideoProject) -> Unit
    ) {
        val initialDraft = _videoDraft.value
        if (initialDraft.topic.isBlank() && initialDraft.cameraPrompt.isBlank()) {
            _videoProgress.value = GenerationProgress.Error("Describe un tema o arma la dirección antes de crear el video.")
            return
        }

        viewModelScope.launch {
            try {
                var draft = initialDraft
                if (draft.cameraPrompt.isBlank() || draft.keyframePrompts.isEmpty()) {
                    _videoProgress.value = GenerationProgress.Working("1/4 Armando dirección cinematográfica...", 0.15f)
                    val direction = aiRepo.assembleVideoDirection(
                        topic = draft.topic.ifBlank { draft.cameraPrompt.take(280) },
                        lookStyle = draft.lookStyle,
                        cameraModel = draft.cameraModel,
                        lens = draft.lens,
                        durationSec = draft.durationSec
                    )
                    draft = draft.copy(
                        title = direction.title,
                        cameraPrompt = draft.cameraPrompt.ifBlank { direction.cameraPrompt },
                        voiceoverScript = draft.voiceoverScript.ifBlank { direction.voiceoverScript },
                        keyframePrompts = direction.keyframePrompts
                    )
                    _videoDraft.value = draft
                }

                val refBitmap: Bitmap? = if (draft.referenceImagePath.isNotBlank()) {
                    MediaStorageHelper.loadBitmapFromPath(draft.referenceImagePath)
                } else null

                val prompts = draft.keyframePrompts.ifEmpty {
                    listOf(
                        "${draft.topic}. ${draft.cameraPrompt}",
                        "${draft.topic}, ángulo medio con lente ${draft.lens}",
                        "${draft.topic}, primer plano expresivo estilo ${draft.lookStyle}",
                        "${draft.topic}, plano final cinematográfico ${draft.cameraModel}"
                    )
                }.take(4)

                val keyframePaths = mutableListOf<String>()
                var lastBitmap: Bitmap? = refBitmap

                prompts.forEachIndexed { index, framePrompt ->
                    val fraction = 0.25f + (index.toFloat() / prompts.size.toFloat()) * 0.6f
                    _videoProgress.value = GenerationProgress.Working(
                        "2/4 Generando fotograma clave ${index + 1}/${prompts.size} en la nube...",
                        fraction
                    )
                    val enrichedPrompt = buildString {
                        append(framePrompt)
                        append(". Cámara: ${draft.cameraModel}, lente ${draft.lens}, estilo ${draft.lookStyle}")
                        if (draft.warmLightPct > 50) append(", iluminación cálida dorada")
                        if (draft.grainPct > 40) append(", textura fílmica sutil")
                    }
                    val generated = aiRepo.generateImage(
                        prompt = enrichedPrompt,
                        modelId = "gemini-nano-banana-2.1",
                        aspectRatio = "9:16",
                        resolution = "1K",
                        styleLook = draft.lookStyle,
                        referenceBitmap = lastBitmap
                    )
                    lastBitmap = generated
                    val path = MediaStorageHelper.saveBitmapToInternal(context, generated, "kf_${index + 1}")
                    keyframePaths.add(path)
                }

                _videoProgress.value = GenerationProgress.Working("3/4 Guardando proyecto y secuencia en Firestore...", 0.92f)
                val project = VideoProject(
                    id = draft.editingProjectId,
                    userId = currentUserId,
                    title = draft.title.ifBlank { draft.topic.take(36) }.ifBlank { "Video Luna AI" },
                    topic = draft.topic,
                    cameraPrompt = draft.cameraPrompt,
                    voiceoverScript = draft.voiceoverScript,
                    durationSec = draft.durationSec.toLong(),
                    lookStyle = draft.lookStyle,
                    cameraModel = draft.cameraModel,
                    lens = draft.lens,
                    warmLightPct = draft.warmLightPct.toLong(),
                    grainPct = draft.grainPct.toLong(),
                    voiceName = draft.voiceName,
                    voicePace = draft.voicePace,
                    status = "ready",
                    keyframePaths = keyframePaths,
                    referenceImagePath = draft.referenceImagePath
                )

                val savedProjectId = firestoreRepo.saveVideoProject(currentUserId, project)
                    .getOrElse { throw it }

                val finalizedProject = project.copy(id = savedProjectId)
                val galleryEntry = GeneratedMedia(
                    userId = currentUserId,
                    title = finalizedProject.title,
                    prompt = finalizedProject.topic.ifBlank { finalizedProject.cameraPrompt },
                    mediaType = "video",
                    modelUsed = "gemini-nano-banana-2.1",
                    aspectRatio = "9:16",
                    styleLook = finalizedProject.lookStyle,
                    seed = Random.nextLong(100_000L, 999_999L),
                    favorite = false,
                    localFilePath = keyframePaths.firstOrNull().orEmpty(),
                    projectId = savedProjectId
                )
                firestoreRepo.saveGeneratedMedia(currentUserId, galleryEntry)

                _activeVideoProject.value = finalizedProject
                _videoProgress.value = GenerationProgress.Completed("Video creado con ${keyframePaths.size} fotogramas IA.")
                onVideoReady(finalizedProject)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Video generation failed", e)
                _videoProgress.value = GenerationProgress.Error(mapAiError(e))
            }
        }
    }

    fun openVideoProject(project: VideoProject) {
        _activeVideoProject.value = project
    }

    fun loadProjectIntoEditor(project: VideoProject) {
        _videoDraft.value = VideoStudioDraft(
            editingProjectId = project.id,
            title = project.title,
            topic = project.topic,
            cameraPrompt = project.cameraPrompt,
            voiceoverScript = project.voiceoverScript,
            durationSec = project.durationSec.toInt().coerceIn(5, 30),
            lookStyle = project.lookStyle,
            cameraModel = project.cameraModel,
            lens = project.lens,
            warmLightPct = project.warmLightPct.toInt().coerceIn(0, 100),
            grainPct = project.grainPct.toInt().coerceIn(0, 100),
            voiceName = project.voiceName,
            voicePace = project.voicePace,
            referenceImagePath = project.referenceImagePath
        )
    }

    fun sendImageToVideoStudio(imagePath: String, prompt: String) {
        _videoDraft.update {
            it.copy(
                referenceImagePath = imagePath,
                topic = prompt.take(300)
            )
        }
    }

    // --- Character Studio ---
    fun updateCharacterDraft(transform: (CharacterStudioDraft) -> CharacterStudioDraft) {
        _characterDraft.update(transform)
    }

    fun loadCharacterIntoStudio(character: LunaCharacter) {
        _characterDraft.value = CharacterStudioDraft(
            editingId = character.id,
            codeName = character.codeName,
            seed = character.seed,
            description = character.description,
            stylePreset = character.stylePreset,
            selectedVariation = character.selectedVariation.toInt().coerceIn(0, 3),
            primaryImagePath = character.localImagePath,
            variationPaths = character.variationPaths
        )
    }

    fun generateNewCharacterWithAi(context: Context) {
        val currentStyle = _characterDraft.value.stylePreset
        viewModelScope.launch {
            _characterProgress.value = GenerationProgress.Working("Diseñando identidad sintética 100% IA...", 0.25f)
            try {
                val concept = aiRepo.generateCharacterConcept(currentStyle)
                _characterProgress.value = GenerationProgress.Working("Renderizando retrato de ${concept.codeName}...", 0.65f)
                val bitmap = aiRepo.generateCharacterVariation(
                    baseDescription = concept.description,
                    expressionInstruction = "Retrato frontal editorial sereno, mirada luminosa",
                    stylePreset = currentStyle,
                    referenceBitmap = null
                )
                val path = MediaStorageHelper.saveBitmapToInternal(context, bitmap, "char_${concept.codeName}")
                _characterDraft.update {
                    it.copy(
                        editingId = "",
                        codeName = concept.codeName,
                        seed = concept.seed,
                        description = concept.description,
                        selectedVariation = 0,
                        primaryImagePath = path,
                        variationPaths = listOf(path)
                    )
                }
                _characterProgress.value = GenerationProgress.Completed("Personaje ${concept.codeName} generado en la nube.")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Character gen failed", e)
                _characterProgress.value = GenerationProgress.Error(mapAiError(e))
            }
        }
    }

    fun generateFacialVariations(context: Context) {
        val draft = _characterDraft.value
        viewModelScope.launch {
            _characterProgress.value = GenerationProgress.Working("Generando 4 variaciones faciales IA...", 0.15f)
            try {
                val refBitmap = MediaStorageHelper.loadBitmapFromPath(draft.primaryImagePath)
                val expressions = listOf(
                    "Expresión serena editorial, iluminación neón cian",
                    "Sonrisa sutil y cálida, ángulo 3/4 cinematográfico",
                    "Mirada intensa futurista, reflejos violeta neón",
                    "Perfil elegante dramático, contraluz dorado"
                )
                val paths = mutableListOf<String>()
                expressions.forEachIndexed { idx, expr ->
                    _characterProgress.value = GenerationProgress.Working(
                        "Variación facial ${idx + 1}/4...",
                        0.25f + (idx * 0.18f)
                    )
                    val bmp = aiRepo.generateCharacterVariation(
                        baseDescription = draft.description,
                        expressionInstruction = expr,
                        stylePreset = draft.stylePreset,
                        referenceBitmap = refBitmap
                    )
                    paths.add(MediaStorageHelper.saveBitmapToInternal(context, bmp, "var_${idx}"))
                }
                _characterDraft.update {
                    it.copy(
                        primaryImagePath = paths.firstOrNull() ?: it.primaryImagePath,
                        variationPaths = paths,
                        selectedVariation = 0
                    )
                }
                _characterProgress.value = GenerationProgress.Completed("4 variaciones faciales listas.")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Variation gen failed", e)
                _characterProgress.value = GenerationProgress.Error(mapAiError(e))
            }
        }
    }

    fun saveCurrentCharacter() {
        val draft = _characterDraft.value
        viewModelScope.launch {
            _characterProgress.value = GenerationProgress.Working("Guardando personaje en Firestore...", 0.6f)
            val chosenImage = draft.variationPaths.getOrNull(draft.selectedVariation)
                ?.takeIf { it.isNotBlank() }
                ?: draft.primaryImagePath

            val character = LunaCharacter(
                id = draft.editingId,
                userId = currentUserId,
                codeName = draft.codeName.ifBlank { "Luna-001" },
                seed = draft.seed,
                description = draft.description,
                stylePreset = draft.stylePreset,
                selectedVariation = draft.selectedVariation.toLong(),
                activeStatus = true,
                localImagePath = chosenImage,
                variationPaths = draft.variationPaths.ifEmpty { listOf(chosenImage).filter { it.isNotBlank() } }
            )
            val result = firestoreRepo.saveCharacter(currentUserId, character)
            result.onSuccess { newId ->
                _characterDraft.update { it.copy(editingId = newId) }
                if (chosenImage.isNotBlank()) {
                    firestoreRepo.saveGeneratedMedia(
                        currentUserId,
                        GeneratedMedia(
                            userId = currentUserId,
                            title = character.codeName,
                            prompt = character.description.ifBlank { "Personaje IA ${character.codeName}" },
                            mediaType = "character",
                            modelUsed = "gemini-nano-banana-2.1",
                            aspectRatio = "3:4",
                            styleLook = character.stylePreset,
                            seed = character.seed,
                            favorite = false,
                            localFilePath = chosenImage,
                            projectId = ""
                        )
                    )
                }
                _characterProgress.value = GenerationProgress.Completed("Personaje ${character.codeName} guardado y activo.")
            }.onFailure { err ->
                _characterProgress.value = GenerationProgress.Error(err.localizedMessage ?: "Error al guardar personaje.")
            }
        }
    }

    // --- Gallery Actions & Device Download ---
    fun toggleFavorite(media: GeneratedMedia) {
        viewModelScope.launch {
            val res = firestoreRepo.toggleFavorite(currentUserId, media.id, !media.favorite)
            res.onFailure { err ->
                _snackbarMessage.value = err.localizedMessage ?: "No se pudo actualizar favoritos."
            }
        }
    }

    fun deleteMedia(media: GeneratedMedia) {
        viewModelScope.launch {
            val res = firestoreRepo.deleteGeneration(currentUserId, media.id)
            res.onSuccess {
                _snackbarMessage.value = "Eliminado de la nube."
            }.onFailure { err ->
                _snackbarMessage.value = err.localizedMessage ?: "No se pudo eliminar."
            }
        }
    }

    fun downloadImageToDevice(context: Context, filePath: String, title: String) {
        viewModelScope.launch {
            val res = MediaStorageHelper.saveImageToDeviceGallery(context, filePath, title)
            _snackbarMessage.value = res.getOrElse { it.localizedMessage ?: "Error al descargar." }
        }
    }

    fun downloadVideoToDevice(context: Context, project: VideoProject) {
        viewModelScope.launch {
            _snackbarMessage.value = "Exportando MP4 al dispositivo..."
            val res = MediaStorageHelper.exportKeyframesVideoToDevice(
                context = context,
                keyframePaths = project.keyframePaths,
                durationSec = project.durationSec.toInt(),
                displayTitle = project.title
            )
            _snackbarMessage.value = res.getOrElse { it.localizedMessage ?: "Error exportando video." }
        }
    }

    private fun mapAiError(e: Exception): String = when (e) {
        is TimeoutCancellationException -> "Tiempo de espera agotado (60s). Verifica tu conexión e inténtalo de nuevo."
        is QuotaExceededException -> "Límite temporal de generación en la nube alcanzado. Intenta en unos momentos."
        else -> e.localizedMessage ?: "Error de conexión con Firebase AI Logic."
    }

    companion object {
        fun provideFactory(currentUserId: String): ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY])
                val db = FirebaseFirestore.getInstance(app.getString(R.string.firestore_database_id))
                LunaStudioViewModel(
                    firestoreRepo = LunaFirestoreRepository(db),
                    aiRepo = LunaAiRepository(),
                    currentUserId = currentUserId
                )
            }
        }
    }
}

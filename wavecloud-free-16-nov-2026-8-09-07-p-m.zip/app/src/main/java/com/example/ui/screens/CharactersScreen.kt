package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Casino
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.FaceRetouchingNatural
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.R
import com.example.model.GenerationProgress
import com.example.model.LunaCharacter
import com.example.model.UiState
import com.example.ui.components.GenerationStatusBanner
import com.example.ui.components.LunaGlassCard
import com.example.ui.components.LunaGradientButton
import com.example.ui.components.LunaLogo
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.EmeraldActive
import com.example.ui.theme.GlassCardElevated
import com.example.ui.theme.MidnightBg
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.SubtleBorderViolet
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.LunaStudioViewModel
import java.io.File
import kotlin.random.Random

@Composable
fun CharactersScreen(
    viewModel: LunaStudioViewModel,
    charactersState: UiState<List<LunaCharacter>>,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val draft by viewModel.characterDraft.collectAsStateWithLifecycle()
    val progress by viewModel.characterProgress.collectAsStateWithLifecycle()
    val savedCharacters = (charactersState as? UiState.Success)?.data.orEmpty()
    val isBusy = progress is GenerationProgress.Working

    val activeDisplayPath = draft.variationPaths.getOrNull(draft.selectedVariation)
        ?.takeIf { it.isNotBlank() && File(it).exists() }
        ?: draft.primaryImagePath.takeIf { it.isNotBlank() && File(it).exists() }

    val variationLabels = listOf("Editorial", "Sutil", "Neón Cian", "Perfil")

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MidnightBg),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 640.dp),
            contentPadding = PaddingValues(horizontal = 18.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header + Badge "100% IA • Sin personas reales"
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        LunaLogo(size = 36.dp)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Personajes IA",
                            style = MaterialTheme.typography.headlineMedium,
                            color = TextPrimary
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(ElectricViolet.copy(alpha = 0.2f))
                            .border(1.dp, NeonCyan.copy(alpha = 0.5f), RoundedCornerShape(50))
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Verified,
                            contentDescription = null,
                            tint = NeonCyan,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = stringResource(R.string.character_badge),
                            style = MaterialTheme.typography.labelSmall,
                            color = TextPrimary
                        )
                    }
                }
            }

            // Saved Characters Selector
            if (savedCharacters.isNotEmpty()) {
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(savedCharacters, key = { it.id }) { charItem ->
                            val isSelected = charItem.codeName == draft.codeName
                            FilterChip(
                                selected = isSelected,
                                onClick = { viewModel.loadCharacterIntoStudio(charItem) },
                                label = { Text(charItem.codeName) },
                                leadingIcon = if (charItem.activeStatus) {
                                    {
                                        Box(
                                            modifier = Modifier
                                                .size(7.dp)
                                                .clip(CircleShape)
                                                .background(EmeraldActive)
                                        )
                                    }
                                } else null,
                                colors = FilterChipDefaults.filterChipColors(
                                    containerColor = GlassCardElevated,
                                    labelColor = TextSecondary,
                                    selectedContainerColor = NeonCyan.copy(alpha = 0.2f),
                                    selectedLabelColor = NeonCyan
                                )
                            )
                        }
                    }
                }
            }

            // Main Character Visualizer
            item {
                LunaGlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    cornerRadius = 24.dp
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(3f / 4f)
                    ) {
                        if (activeDisplayPath != null) {
                            AsyncImage(
                                model = File(activeDisplayPath),
                                contentDescription = draft.codeName,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Image(
                                painter = painterResource(id = R.drawable.img_luna_character),
                                contentDescription = draft.codeName,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }

                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        listOf(
                                            Color.Transparent,
                                            Color.Transparent,
                                            MidnightBg.copy(alpha = 0.85f)
                                        )
                                    )
                                )
                        )

                        Row(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Bottom
                        ) {
                            Column {
                                Text(
                                    text = draft.codeName,
                                    style = MaterialTheme.typography.headlineMedium,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "Seed: ${draft.seed} • ${draft.stylePreset}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = NeonCyan
                                )
                            }

                            OutlinedButton(
                                onClick = { viewModel.generateNewCharacterWithAi(context) },
                                enabled = !isBusy,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.testTag("generate_new_character_button")
                            ) {
                                Icon(Icons.Rounded.AutoAwesome, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Nuevo IA", color = TextPrimary)
                            }
                        }
                    }
                }
            }

            // Facial Variations Thumbnail Selector
            item {
                LunaGlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Variaciones faciales",
                                style = MaterialTheme.typography.titleMedium,
                                color = TextPrimary
                            )
                            OutlinedButton(
                                onClick = { viewModel.generateFacialVariations(context) },
                                enabled = !isBusy,
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                modifier = Modifier.testTag("generate_variations_button")
                            ) {
                                Icon(Icons.Rounded.FaceRetouchingNatural, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Generar 4", style = MaterialTheme.typography.labelSmall, color = NeonCyan)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            for (index in 0..3) {
                                val thumbPath = draft.variationPaths.getOrNull(index)
                                    ?.takeIf { it.isNotBlank() && File(it).exists() }
                                val isSelected = draft.selectedVariation == index

                                Column(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable {
                                            viewModel.updateCharacterDraft { it.copy(selectedVariation = index) }
                                        }
                                        .testTag("character_variation_$index"),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .aspectRatio(1f)
                                            .clip(RoundedCornerShape(12.dp))
                                            .border(
                                                width = if (isSelected) 2.dp else 1.dp,
                                                color = if (isSelected) NeonCyan else SubtleBorderViolet,
                                                shape = RoundedCornerShape(12.dp)
                                            )
                                    ) {
                                        if (thumbPath != null) {
                                            AsyncImage(
                                                model = File(thumbPath),
                                                contentDescription = variationLabels[index],
                                                contentScale = ContentScale.Crop,
                                                modifier = Modifier.fillMaxSize()
                                            )
                                        } else {
                                            Image(
                                                painter = painterResource(id = R.drawable.img_luna_character),
                                                contentDescription = variationLabels[index],
                                                contentScale = ContentScale.Crop,
                                                alpha = if (index == 0) 1f else 0.65f,
                                                modifier = Modifier.fillMaxSize()
                                            )
                                        }
                                        if (isSelected) {
                                            Box(
                                                modifier = Modifier
                                                    .align(Alignment.TopEnd)
                                                    .padding(4.dp)
                                                    .size(20.dp)
                                                    .clip(CircleShape)
                                                    .background(NeonCyan),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Rounded.Check,
                                                    contentDescription = "Seleccionado",
                                                    tint = MidnightBg,
                                                    modifier = Modifier.size(14.dp)
                                                )
                                            }
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = variationLabels[index],
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                        ),
                                        color = if (isSelected) NeonCyan else TextSecondary
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Metadata Card (Nombre/ID, Seed, Descripción)
            item {
                LunaGlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedTextField(
                                value = draft.codeName,
                                onValueChange = { name ->
                                    viewModel.updateCharacterDraft { it.copy(codeName = name.take(60)) }
                                },
                                label = { Text("Nombre / ID") },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = NeonCyan,
                                    unfocusedBorderColor = SubtleBorderViolet,
                                    focusedTextColor = TextPrimary,
                                    unfocusedTextColor = TextPrimary
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("character_name_input")
                            )

                            OutlinedTextField(
                                value = draft.seed.toString(),
                                onValueChange = { raw ->
                                    val numeric = raw.filter { it.isDigit() }.toLongOrNull() ?: 0L
                                    viewModel.updateCharacterDraft { it.copy(seed = numeric) }
                                },
                                label = { Text("Seed") },
                                singleLine = true,
                                trailingIcon = {
                                    IconButton(
                                        onClick = {
                                            viewModel.updateCharacterDraft {
                                                it.copy(seed = Random.nextLong(100_000L, 999_999L))
                                            }
                                        }
                                    ) {
                                        Icon(Icons.Rounded.Casino, contentDescription = "Seed aleatoria", tint = NeonCyan)
                                    }
                                },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = NeonCyan,
                                    unfocusedBorderColor = SubtleBorderViolet,
                                    focusedTextColor = TextPrimary,
                                    unfocusedTextColor = TextPrimary
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.weight(1f)
                            )
                        }

                        OutlinedTextField(
                            value = draft.description,
                            onValueChange = { desc ->
                                viewModel.updateCharacterDraft { it.copy(description = desc.take(1000)) }
                            },
                            label = { Text("Descripción detallada") },
                            placeholder = { Text("Rasgos, estilo visual, iluminación...", color = TextMuted) },
                            minLines = 3,
                            maxLines = 5,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NeonCyan,
                                unfocusedBorderColor = SubtleBorderViolet,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("character_description_input")
                        )
                    }
                }
            }

            item {
                GenerationStatusBanner(
                    progress = progress,
                    onDismiss = { viewModel.resetCharacterProgress() }
                )
            }

            // Bottom Save Character CTA
            item {
                LunaGradientButton(
                    text = stringResource(R.string.save_character),
                    onClick = { viewModel.saveCurrentCharacter() },
                    enabled = !isBusy,
                    icon = Icons.Rounded.Save,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("save_character_button")
                )
            }

            item { Spacer(modifier = Modifier.height(12.dp)) }
        }
    }
}

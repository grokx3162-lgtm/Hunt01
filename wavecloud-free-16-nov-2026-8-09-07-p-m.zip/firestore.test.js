const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_uid_123";
const BOB_UID = "bob_uid_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated users cannot read or write any Luna AI collection", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("characters").get());
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("projects").get());
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("generations").get());
});

test("Owner can create, update, and list characters; cross-user and ghost fields fail", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const now = new Date(Date.now() - 2000);

  const validChar = {
    userId: ALICE_UID,
    codeName: "Luna-001",
    seed: 849201,
    description: "Personaje editorial futurista con iluminación neón.",
    stylePreset: "Profesional",
    selectedVariation: 0,
    activeStatus: true,
    localImagePath: "/data/user/0/app/files/luna_001.jpg",
    variationPaths: ["/data/user/0/app/files/luna_v0.jpg"],
    createdAt: now,
    updatedAt: now,
  };

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("characters").doc("char_1").set(validChar)
  );
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("characters").get()
  );
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("characters").doc("char_1").update({
      selectedVariation: 2,
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Reject ghost field
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("characters").doc("char_bad").set({
      ...validChar,
      id: "char_bad",
    })
  );

  // Cross-user isolation
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("characters").doc("char_1").get()
  );
});

test("Owner can create and update video projects; archived projects are locked", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date(Date.now() - 2000);

  const validProject = {
    userId: ALICE_UID,
    title: "Neón en Tokio",
    topic: "Un recorrido nocturno cinematográfico bajo lluvia neón.",
    cameraPrompt: "Travelling lento con lente 50 mm y luz cálida.",
    voiceoverScript: "En la quietud de la medianoche, la luz cobra vida.",
    durationSec: 15,
    lookStyle: "Profesional",
    cameraModel: "ARRI Alexa 35",
    lens: "50 mm",
    warmLightPct: 35,
    grainPct: 18,
    voiceName: "Luna Clara",
    voicePace: "Natural",
    status: "ready",
    keyframePaths: ["/files/kf_1.jpg"],
    referenceImagePath: "",
    createdAt: now,
    updatedAt: now,
  };

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("projects").doc("proj_1").set(validProject)
  );
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("projects").doc("proj_1").update({
      durationSec: 20,
      status: "archived",
      updatedAt: new Date(Date.now() - 1000),
    })
  );
  // Terminal state lock: archived project cannot be updated
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("projects").doc("proj_1").update({
      durationSec: 10,
      updatedAt: new Date(Date.now() - 500),
    })
  );
});

test("Owner can create generations and toggle favorite", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date(Date.now() - 2000);

  const validGen = {
    userId: ALICE_UID,
    title: "Retrato Holográfico",
    prompt: "Retrato editorial con iluminación violeta neón.",
    mediaType: "image",
    modelUsed: "gemini-nano-banana-2.1",
    aspectRatio: "1:1",
    styleLook: "Surreal",
    seed: 102938,
    favorite: false,
    localFilePath: "/files/gen_1.jpg",
    projectId: "",
    createdAt: now,
    updatedAt: now,
  };

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("generations").doc("gen_1").set(validGen)
  );
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("generations").doc("gen_1").update({
      favorite: true,
      updatedAt: new Date(Date.now() - 1000),
    })
  );
  // Cannot mutate prompt or mediaType
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("generations").doc("gen_1").update({
      prompt: "Tampered",
      updatedAt: new Date(Date.now() - 500),
    })
  );
});
